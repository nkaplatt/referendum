<!DOCTYPE html>
<!-- Last Published: Sun May 01 2016 23:29:54 GMT+0000 (UTC) -->
<html data-wf-site="56fd24aaaea6500c763220cf" data-wf-page="57189c92b6f10eb45d8c93dc">
<head>
  <meta charset="utf-8">
  <title>Immigration and the EU</title>
  <meta name="description" content="Should we leave or stay in the EU.  We provide accurate, impartial information on the referendum so that you can cast an informed vote.">
  <meta property="og:title" content="Immigration and the EU">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/normalize.css">
  <link rel="stylesheet" type="text/css" href="css/webflow.css">
  <link rel="stylesheet" type="text/css" href="css/los-template.webflow.css">
  <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.4.7/webfont.js"></script>
  <script>
    WebFont.load({
        google: {
          families: ["Open Sans:300,300italic,400,400italic,600,600italic,700,700italic,800,800italic","Varela Round:400","Ubuntu:300,300italic,400,400italic,500,500italic,700,700italic","Lato:100,100italic,300,300italic,400,400italic,700,700italic,900,900italic","Montserrat:400,700","Raleway:100,200,300,regular,500,600,700,800,900"]
        }
      });
  </script>
  <script type="text/javascript" src="js/modernizr.js"></script>
  <link rel="shortcut icon" type="image/x-icon" href="images/Favicon.png">
  <link rel="apple-touch-icon" href="https://daks2k3a4ib2z.cloudfront.net/img/webclip.png">
  <script type="text/javascript">
    var _gaq = _gaq || [];
      _gaq.push(['_setAccount', 'UA-76346760-1'], ['_trackPageview']);
      (function() {
        var ga = document.createElement('script');
        ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
      })();
  </script>
</head>
<body class="body topics">
  <div data-collapse="medium" data-animation="default" data-duration="400" data-contain="1" class="w-nav navbar">
    <div class="w-container">
      <a href="new-homepage.php" class="w-nav-brand logo-container">
        <h1 class="logo-text"><strong>leave</strong>or<strong>stay</strong>.co.uk</h1>
      </a>
      <nav role="navigation" class="w-nav-menu">
        <a href="immigration.php" class="w-nav-link nav-link">Immigration</a>
        <a href="sovereignty-and-the-law.php" class="w-nav-link nav-link">Sovereignty</a>
        <a href="trade.php" class="w-nav-link nav-link">Trade</a>
        <a href="jobs.php" class="w-nav-link nav-link">Jobs</a>
        <a href="defence.php" class="w-nav-link nav-link">Defense</a>
        <a href="signup.php" class="w-button hero-button">Sign up/login</a>
      </nav>
      <div class="w-nav-button menu">
        <div class="w-icon-nav-menu"></div>
      </div>
    </div>
  </div>
  <div class="w-section hero">
    <div class="w-container hero-container immigration">
      <img src="images/immi-01.png" class="hero-image">
      <h1 class="hero-title word">immigration.</h1>
      <h1 class="hero-title">Question covered include:</h1>
      <h1 class="hero-title title-2">Who can enter the UK?<br>Do we have 'control' of our borders?<br>Do migrants 'take' UK jobs?</h1>
      <a href="#Intro--start" class="w-button hero-button">start topic</a>
      <a href="sovereignty-and-the-law.php" class="w-button hero-button _2">Skip this topic</a>
    </div>
  </div>
  <div id="Intro--start" class="w-section intro-panel">
    <h1 class="grid-header">Overview - What's the story with <strong>Immigration:</strong></h1>
    <p class="overview-subtitle">Immigration is potentially the most 'heated' topic involved in this referendum. Why? Because to a large extent its the least understood. &nbsp;The vast majority of immigrants entering the UK come from outside the EU so aren't bound by EU "free movement rules", although this percentage is shrinking. The UK already operates a points based system, commonly referred to as the "Australian style" system, for non-EU migrants. Experts believe reform of this system is what is needed to reduce immigration to the 'tens of thousands' which is believed to be the sustainable level of immigration to the UK per year.</p>
    <div class="learn-how-to-use">How does this work?</div>
    <div class="drop">
      <div class="arrow-instruction">Every time you see this arrow, click it.</div>
      <img width="40" src="images/down arrow.svg" data-ix="drop-how-to" class="down-arrow">
    </div>
    <p data-ix="display-none-on-load" class="overview-dropdown">This is over 500 hrs worth of research condensed into about 5 minutes worth of clear, concise, quality reading. Each question has been researched, scrutinised and then made available to you in one place, all so you can make a more informed decision, faster.</p>
    <div data-ix="display-none-on-load" class="w-row how-to-row">
      <div class="w-col w-col-4 read">
        <h3 class="read-heading">1. Read</h3>
        <img height="100" src="images/immigration icon.png">
        <p class="read-para-1">Have a glance over the tiles below and get an understanding of what is going on with the EU and UK today.</p>
      </div>
      <div class="w-col w-col-4 react">
        <h3 class="react-heading">2. React</h3>
        <img height="100" src="images/happy without word.png">
        <p class="read-para">Use the 5 emojis to react to how you feel about the information you read.</p>
      </div>
      <div class="w-col w-col-4 impact">
        <h3 class="impact-heading">3. Impact</h3>
        <img height="100" src="images/Icon-check.png">
        <p class="read-para">We'll then use some clever computing to give you all the options on the table so you can decide what happens next.</p>
      </div>
    </div>
  </div>
  <div class="w-section tb-slider-section">
    <h1 class="topic-header">Top questions on immigration</h1>
    <div data-animation="slide" data-duration="500" data-infinite="1" class="w-slider tb-slider">
      <div class="w-slider-mask tb-mask">
        <div class="w-slide slide-1">
          <div class="w-container container-tb">
            <div class="key-point-1">
              <h1 class="card-1-header">'Would leaving the EU allow us to control our borders?'</h1>
              <p class="card-text">'EU membership stops us controlling who comes into our country, on what terms, and who can be removed. The system is out of control.'</p>
              <a href="#" data-ix="show-overview-1" class="w-button show-overview-1">Click to find out</a>
            </div>
          </div>
        </div>
        <div class="w-slide slide-2">
          <div class="w-container container-tb">
            <div class="key-point-2">
              <h1 class="card-2-header">'Do immigrants take jobs away from UK nationals?'</h1>
              <p class="card-text">As a result of the 'free movement of people' principle, EU nationals directly compete against UK citizens for jobs in the UK.</p>
              <a href="#" data-ix="show-overview-2" class="w-button show-overview-2">Click to find out</a>
            </div>
          </div>
        </div>
        <div class="w-slide slide-3">
          <div class="w-container container-tb">
            <div class="key-point-3">
              <h1 class="why-people-card-header">'Do migrants put pressure on public services like the NHS?'</h1>
              <p class="card-text">'We can not just reduce the pressure on the NHS, but can stop sending £350m to the EU every week and instead spend it on our priorities. £350m is enough to build a brand new, fully staffed hospital every week.'</p>
              <a href="#" data-ix="show-overview-3" class="w-button show-overview-3">Click to find out</a>
            </div>
          </div>
        </div>
      </div>
      <div data-ix="overview-hide" class="w-slider-arrow-left">
        <div class="w-icon-slider-left left-arrow"></div>
        <div class="next">Next Card</div>
      </div>
      <div data-ix="overview-hide" class="w-slider-arrow-right">
        <div class="w-icon-slider-right right-arrow"></div>
        <div class="next">Next Card</div>
      </div>
      <div class="w-slider-nav w-round slider-1-nav"></div>
    </div>
  </div>
  <div class="w-section argument-section">
    <div data-ix="display-none-on-load" class="w-row argument-row">
      <div class="w-col w-col-4 overview-1">
        <div class="sticky-footer">
          <h1 class="overview-heading">Overview&nbsp;</h1>
          <p class="basics-paragraph">The UK currently has over 600,000 new migrants entering the UK to live and work every year, an unsustainable amount given the size of the UK. To bring immigration under control experts suggest we need net migration levels (the number entering minus the number leaving ) to be about 100,000 or less. The UK does have an 'Australian' style points based system for non-EU migrants which doesn't apply to EU migrants BUT currently the majority of migrants are from non EU countries anyway.</p>
          <div class="fill-empty-space"></div>
          <div class="emoticon-div">
            <div class="how-emoticons-work">How does this make you feel?</div>
            <div class="emoticons-19">
              <img width="50" src="images/angry with word.png" data-ix="anger-selected-19" class="anger-19">
              <img width="50" src="images/surprised with word.png" data-ix="shock-selected-19" class="shock-19">
              <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-19" class="indifferent-19">
              <img width="50" src="images/happy with word.png" data-ix="happy-selected-19" class="happy-19">
              <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-19" class="delighted-19">
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-4 leave-1">
        <div class="sticky-footer">
          <h1 class="leave-heading">Impact if we leave</h1>
          <p class="basics-paragraph"><strong class="impact-answer-leave">Moderate.</strong>
            <br>
            <br>All migrants would probably have to enter through the same points based system and require a visa. No one knows how free movement of people would work for UK nationals abroad or under what terms EU nationals could enter the UK. However it is important to note that reform of the points based system would still need to take place by the UK government to truly bring migration levels under control.</p>
          <div></div>
          <div class="emoticon-div">
            <div class="how-emoticons-work">How does this make you feel?</div>
            <div class="emoticons-20">
              <img width="50" src="images/angry with word.png" data-ix="anger-selected-20" class="anger-20">
              <img width="50" src="images/surprised with word.png" data-ix="shock-selected-20" class="shock-20">
              <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-20" class="indifferent-20">
              <img width="50" src="images/happy with word.png" data-ix="happy-selected-20" class="happy-20">
              <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-20" class="delighted-20">
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-4 stay-1">
        <div class="sticky-footer">
          <h1 class="stay-heading">Impact if we stay</h1>
          <p class="basics-paragraph"><strong class="impact-answer-stay">Unknown.</strong>&nbsp;
            <br>
            <br>The main influx of EU migrants came from countries that joined the EU in 2004, which includes Poland and Bulgaria. With those countries now members there is not a large pool of economic migrants out there (besides Turkey) &nbsp;that could be 'released' and lead to a new wave. None the less the UK would still have to accept free movement rules but can reform its non EU points based system from within the EU.</p>
          <div class="fill-empty-space"></div>
          <div class="emoticon-div">
            <div class="how-emoticons-work">How does this make you feel?</div>
            <div class="emoticons-21">
              <img width="50" src="images/angry with word.png" data-ix="anger-selected-21" class="anger-21">
              <img width="50" src="images/surprised with word.png" data-ix="shock-selected-21" class="shock-21">
              <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-21" class="indifferent-21">
              <img width="50" src="images/happy with word.png" data-ix="happy-selected-21" class="happy-21">
              <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-21" class="delighted-21">
            </div>
          </div>
        </div>
      </div>
    </div>
    <div data-ix="display-none-on-load" class="w-row argument-row-2">
      <div class="w-col w-col-4 overview-2">
        <div class="sticky-footer">
          <h1 class="overview-heading">Overview&nbsp;</h1>
          <p class="basics-paragraph">There is very little evidence to suggest that free movement of people causes job loss for UK nationals. The vast majority of the studies we examined (36 in total) found that immigration in total had little effect on native employment or on average wages. They did find, however, that it increased wage inequality slightly, especially for those on the lower end of the income scale (approx. £16k-£21k per year)</p>
          <div class="evidence"><a href="https://www.cer.org.uk/sites/default/files/publications/attachments/pdf/2013/pb_imm_uk_27sept13-7892.pdf">Further reading</a>
          </div>
          <div class="fill-empty-space"></div>
          <div class="emoticon-div">
            <div class="how-emoticons-work">How does this make you feel?</div>
            <div class="emoticons-22">
              <img width="50" src="images/angry with word.png" data-ix="anger-selected-22" class="anger-22">
              <img width="50" src="images/surprised with word.png" data-ix="shock-selected-22" class="shock-22">
              <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-22" class="indifferent-22">
              <img width="50" src="images/happy with word.png" data-ix="happy-selected-22" class="happy-22">
              <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-22" class="delighted-22">
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-4 leave-2">
        <div class="sticky-footer">
          <h1 class="leave-heading">Impact if we leave</h1>
          <p class="basics-paragraph"><strong class="impact-answer-leave">Moderate.</strong>
            <br>
            <br> The UK would, theoretically, have greater control over who entered the UK and for what reasons as all migrant applicants are process through the points based system. Some "leave" scenarios involve much tighter immigration policies for EU citizens, while other scenarios would bring no change to immigration policies at all. It’s not possible to resolve this question before the referendum, since post-leave policies would depend not just on the UK government’s decisions, but also on potentially lengthy negotiations with the EU.</p>
          <div class="fill-empty-space"></div>
          <div class="emoticon-div">
            <div class="how-emoticons-work">How does this make you feel?</div>
            <div class="emoticons-23">
              <img width="50" src="images/angry with word.png" data-ix="anger-selected-23" class="anger-23">
              <img width="50" src="images/surprised with word.png" data-ix="shock-selected-23" class="shock-23">
              <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-23" class="indifferent-23">
              <img width="50" src="images/happy with word.png" data-ix="happy-selected-23" class="happy-23">
              <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-23" class="delighted-23">
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-4 stay-2">
        <div class="sticky-footer">
          <h1 class="stay-heading">Impact if we stay</h1>
          <p class="basics-paragraph"><strong class="impact-answer-stay">Minimal.</strong>&nbsp;
            <br>
            <br>The UK would continue to operate under the rules of free movement and have both the benefits and drawbacks of this arrangement.</p>
          <div class="fill-empty-space"></div>
          <div class="emoticon-div">
            <div class="how-emoticons-work">How does this make you feel?</div>
            <div class="emoticons-24">
              <img width="50" src="images/angry with word.png" data-ix="anger-selected-24" class="anger-24">
              <img width="50" src="images/surprised with word.png" data-ix="shock-selected-24" class="shock-24">
              <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-24" class="indifferent-24">
              <img width="50" src="images/happy with word.png" data-ix="happy-selected-24" class="happy-24">
              <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-24" class="delighted-24">
            </div>
          </div>
        </div>
      </div>
    </div>
    <div data-ix="display-none-on-load" class="w-row argument-row-3">
      <div class="w-col w-col-4 overview-3">
        <div class="sticky-footer">
          <h1 class="overview-heading">Overview&nbsp;</h1>
          <p class="basics-paragraph">There are serious difficulties in accurately measuring the effects of migration on the availability and quality of public services. Studies on the 'net fiscal impact' of migration have generally found that, overall, the foreign born make national and local tax contributions that are&nbsp;roughly comparable&nbsp;to the cost of the services and benefits they receive (in other words migrants don't drain public resource.)
            <br>
            <br>The extent to which migrants rely on public services will vary depending on the characteristics of migrants and on the service in question. For example, newly arriving migrants tend to be young adults. Because of their age, they are expected to be less likely to use adult social care and most health services than the UK born. However, they are more likely than the UK born to have young children, and so they are expected to rely more heavily on education and maternity care.</p>
          <div class="evidence"><a href="https://fullfact.org/immigration/how-immigrants-affect-public-finances/">Further reading</a>
          </div>
          <div class="fill-empty-space"></div>
          <div class="emoticon-div">
            <div class="how-emoticons-work">How does this make you feel?</div>
            <div class="emoticons-25">
              <img width="50" src="images/angry with word.png" data-ix="anger-selected-25" class="anger-25">
              <img width="50" src="images/surprised with word.png" data-ix="shock-selected-25" class="shock-25">
              <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-25" class="indifferent-25">
              <img width="50" src="images/happy with word.png" data-ix="happy-selected-25" class="happy-25">
              <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-25" class="delighted-25">
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-4 leave-3">
        <div class="sticky-footer">
          <h1 class="leave-heading">Impact if we leave</h1>
          <p class="basics-paragraph"><strong class="impact-answer-leave">Unknown.</strong>
            <br>
            <br>The NHS in England, which is the one that the Westminster government can directly increase funding to, had a budget last year of £116bn, which works out at £2.25bn a week. or £321,428,571.42 per day. On these numbers the £276 million 'saved' would be 'used up' in about 18hrs. Depending on what model was adopted with regards to free movement of people, it will not be possible to tell what the impact will be on the NHS and other public services.</p>
          <div class="fill-empty-space"></div>
          <div class="emoticon-div">
            <div class="how-emoticons-work">How does this make you feel?</div>
            <div class="emoticons-26">
              <img width="50" src="images/angry with word.png" data-ix="anger-selected-26" class="anger-26">
              <img width="50" src="images/surprised with word.png" data-ix="shock-selected-26" class="shock-26">
              <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-26" class="indifferent-26">
              <img width="50" src="images/happy with word.png" data-ix="happy-selected-26" class="happy-26">
              <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-26" class="delighted-26">
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-4 stay-3">
        <div class="sticky-footer">
          <h1 class="stay-heading">Impact if we stay</h1>
          <p class="basics-paragraph"><strong class="impact-answer-stay">Minimal.</strong>
            <br>
            <br>The UK would have to be prepared to continually adjust what resources it had in place to deal with an increasing migrant population but overall little day to day impact would be felt.</p>
          <div class="fill-empty-space"></div>
          <div class="emoticon-div">
            <div class="how-emoticons-work">How does this make you feel?</div>
            <div class="emoticons-27">
              <img width="50" src="images/angry with word.png" data-ix="anger-selected-27" class="anger-27">
              <img width="50" src="images/surprised with word.png" data-ix="shock-selected-27" class="shock-27">
              <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-27" class="indifferent-27">
              <img width="50" src="images/happy with word.png" data-ix="happy-selected-27" class="happy-27">
              <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-27" class="delighted-27">
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div id="Section-1" class="w-section section-1">
    <h1 class="blue-section-header">Here are the most popular Google searches on this topic answered, right here:</h1>
    <h4 class="how-to-use-the-grid-header">Most popular searches</h4>
    <img width="25" src="images/down arrow.svg" data-ix="first-column-set-showhide" class="drop-down-topics">
    <div data-ix="display-none-on-load" class="w-row first-column-set">
      <div class="w-col w-col-5 column-1">
        <div class="card-1">
          <div class="sticky-footer">
            <h3 class="card-header-1">Show net migration levels to the UK over time:</h3>
            <h1 class="headline-fact">330,000<br>net in 2015</h1>
            <img src="images/Screen Shot 2016-04-16 at 14.45.51.png" class="immigration-trend-graph">
            <a href="#" data-ix="p1" class="w-button button-1">More info</a>
            <p data-ix="display-none-on-load" class="p1">Net migration is immigration (people entering the UK) minus people leaving the UK (emmigration) with the difference between them knows as net migration.</p>
            <div class="evidence"><a href-disabled="http://www.migrationobservatory.ox.ac.uk/briefings/migration-flows-a8-and-other-eu-migrants-and-uk" href-disabled-default-color="" href-disabled-underline="" href="http://www.migrationobservatory.ox.ac.uk/briefings/migration-flows-a8-and-other-eu-migrants-and-uk" target="_blank">Where did we get this from?</a>
            </div>
            <div class="fill-empty-space"></div>
            <div class="emoticon-div">
              <div class="how-emoticons-work">How does this make you feel?</div>
              <div class="emoticons">
                <img width="50" src="images/angry with word.png" data-ix="anger-selected" class="anger">
                <img width="50" src="images/surprised with word.png" data-ix="shock-selected" class="shock">
                <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected" class="indifferent">
                <img width="50" src="images/happy with word.png" data-ix="happy-selected" class="happy">
                <img width="50" src="images/delighted with word.png" data-ix="delighted-selected" class="delighted">
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-4 column-2">
        <div class="card-2">
          <div class="sticky-footer">
            <h3 class="card-header-2">How many EU migrants currently live in the UK?</h3>
            <h1 class="headline-fact">3.3</h1>
            <h1 class="headline-fact-subtitle">million</h1>
            <a href="#" data-ix="p2" class="w-button button-2">Show in&nbsp;context</a>
            <p data-ix="display-none-on-load" class="p2">According to the Office for National Statistics (ONS) Labour Force Survey estimates for 2015, there are 3.3 million EU citizens in the UK and 5.3 million from non-EU countries.</p>
            <div class="evidence"><a href-disabled="http://www.migrationobservatory.ox.ac.uk/briefings/migration-flows-a8-and-other-eu-migrants-and-uk" href-disabled-default-color="" href-disabled-underline="" href="http://www.migrationwatchuk.org/statistics-population-country-birth" target="_blank">Where did we get this from?</a>
            </div>
            <div class="fill-empty-space"></div>
            <div class="emoticon-div">
              <div class="how-emoticons-work">How does this make you feel?</div>
              <div class="emoticons-2">
                <img width="50" src="images/angry with word.png" data-ix="anger-selected-2" class="anger-2">
                <img width="50" src="images/surprised with word.png" data-ix="shock-selected-2" class="shock-2">
                <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-2" class="indifferent-2">
                <img width="50" src="images/happy with word.png" data-ix="happy-selected-2" class="happy-2">
                <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-2" class="delighted-2">
              </div>
            </div>
          </div>
        </div>
        <div class="card-3">
          <div class="sticky-footer">
            <h1 class="card-heading-3">How many work in the UK?</h1>
            <h1 class="headline-fact">2.1</h1>
            <h1 class="headline-fact-subtitle">million</h1>
            <a href="#" data-ix="p3" class="w-button button-3">More info</a>
            <p data-ix="display-none-on-load" class="p3">There is a general increasing trend in the number of EU born in the UK labour market over time, reaching its peak in the first quarter of 2015 with about 1.9 million EU workers. The upward trend is primarily attributed to increases in the number of accession workers over time</p>
            <div class="evidence"><a target="_blank" href="http://www.migrationobservatory.ox.ac.uk/briefings/migration-flows-a8-and-other-eu-migrants-and-uk">Where did we get this from?</a>
            </div>
            <div class="fill-empty-space"></div>
            <div class="emoticon-div">
              <div class="how-emoticons-work">How does this make you feel?</div>
              <div class="emoticons-3">
                <img width="50" src="images/angry with word.png" data-ix="anger-selected-3" class="anger-3">
                <img width="50" src="images/surprised with word.png" data-ix="shock-selected-3" class="shock-3">
                <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-3" class="indifferent-3">
                <img width="50" src="images/happy with word.png" data-ix="happy-selected-3" class="happy-3">
                <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-3" class="delighted-3">
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-3 column-3">
        <div class="card-4">
          <div class="sticky-footer">
            <h1 class="card-heading-4">Where do they come from?</h1>
            <a href="#" data-ix="p4" class="w-button button-4">More info</a>
            <p data-ix="display-none-on-load" class="p4">According to the Office for National Statistics (ONS) Labour Force Survey estimates for 2015, there are 3.3 million EU citizens in the UK – 1.6 million from the EU14, 1.3 million from the EU8, 300,000 from Romania and Bulgaria and the remainder from the other EU countries of Malta, Cyprus and Croatia[5].</p>
            <div class="evidence"><a href-disabled="http://www.migrationobservatory.ox.ac.uk/briefings/migration-flows-a8-and-other-eu-migrants-and-uk" href-disabled-default-color="" href-disabled-underline="" href="http://www.migrationwatchuk.org/statistics-population-country-birth" target="_blank">Where did we get this from?</a>
            </div>
            <div class="fill-empty-space"></div>
            <div class="emoticon-div">
              <div class="how-emoticons-work">How does this make you feel?</div>
              <div class="emoticons-4">
                <img width="50" src="images/angry with word.png" data-ix="anger-selected-4" class="anger-4">
                <img width="50" src="images/surprised with word.png" data-ix="shock-selected-4" class="shock-4">
                <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-4" class="indifferent-4">
                <img width="50" src="images/happy with word.png" data-ix="happy-selected-4" class="happy-4">
                <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-4" class="delighted-4">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div data-ix="display-none-on-load" class="w-row second-column-set">
      <div class="w-col w-col-5 cc1">
        <div class="card-5">
          <div class="sticky-footer">
            <h1 class="card-header-5">What are the motivations for coming over?</h1>
            <h1 class="headline-fact">Primarily economic</h1>
            <a href="#" data-ix="p5" class="w-button button-5">More info</a>
            <p data-ix="display-none-on-load" class="p5">About 65% of EU nationals migrating to the UK come for work related reasons, followed by those who come for formal study.</p>
            <div class="evidence"><a href-disabled="http://www.migrationobservatory.ox.ac.uk/briefings/migration-flows-a8-and-other-eu-migrants-and-uk" href-disabled-default-color="" href-disabled-underline="" href="http://www.migrationobservatory.ox.ac.uk/briefings/migration-flows-a8-and-other-eu-migrants-and-uk" target="_blank">Where did we get this from?</a>
            </div>
            <div class="fill-empty-space"></div>
            <div class="emoticon-div">
              <div class="how-emoticons-work">How does this make you feel?</div>
              <div class="emoticons-5">
                <img width="50" src="images/angry with word.png" data-ix="anger-selected-5" class="anger-5">
                <img width="50" src="images/surprised with word.png" data-ix="shock-selected-5" class="shock-5">
                <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-5" class="indifferent-5">
                <img width="50" src="images/happy with word.png" data-ix="happy-selected-5" class="happy-5">
                <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-5" class="delighted-5">
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-4 cc2">
        <div class="card-6">
          <div class="sticky-footer">
            <h1 class="card-header-6">Is the UK becoming overcrowded?</h1>
            <h1 class="headline-fact">It's on its way.</h1>
            <a href="#" data-ix="p6" class="w-button button-6">Show context</a>
            <p data-ix="display-none-on-load" class="p6">High net migration has resulted in rapid population growth. The UK population currently stands at around 65 million. The Office of National Statistics ‘high’ migration scenario projects that the UK population will now increase by around 500,000 a year - the equivalent to a new city the size of Liverpool every year. This is unsustainable. It would result in the population growing by nearly eight million over the next fifteen years bringing it to 73 million.</p>
            <div class="evidence"><a href-disabled="http://www.migrationobservatory.ox.ac.uk/briefings/migration-flows-a8-and-other-eu-migrants-and-uk" href-disabled-default-color="" href-disabled-underline="" href="http://www.migrationwatchuk.org/what-is-the-problem" target="_blank">Where did we get this from?</a>
            </div>
            <div class="fill-empty-space"></div>
            <div class="emoticon-div">
              <div class="how-emoticons-work">How does this make you feel?</div>
              <div class="emoticons-6">
                <img width="50" src="images/angry with word.png" data-ix="anger-selected-6" class="anger-6">
                <img width="50" src="images/surprised with word.png" data-ix="shock-selected-6" class="shock-6">
                <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-6" class="indifferent-6">
                <img width="50" src="images/happy with word.png" data-ix="happy-selected-6" class="happy-6">
                <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-6" class="delighted-6">
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-3 cc3"></div>
    </div>
    <a href="#Intro--start" data-ix="display-none-on-load" class="w-button back-to-top">Back To Top</a>
  </div>
  <div id="Section-2" class="w-section section-2">
    <h4 class="how-to-use-the-grid-header">Impact on Jobs</h4>
    <img width="25" src="images/down arrow.svg" data-ix="drop-down-section-3" class="drop-down-topics">
    <div data-ix="display-none-on-load" class="w-row third-column-set">
      <div class="w-col w-col-5 column-7">
        <div class="card-7">
          <div class="sticky-footer">
            <h1 class="card-heading-7">What types of work do they do?</h1>
            <h1 class="headline-fact-long">A real mixture.</h1>
            <a href="#" data-ix="p7" class="w-button button-7">More info</a>
            <p data-ix="display-none-on-load" class="p7">For the purposes of this we have split all workers into two groups, skilled and unskilled. There is no quick answer to this but in a nutshell people from EU14 countries are more likely to be in skilled worked and people from EU8 countries are more likely to be in unskilled work.</p>
            <div class="evidence"><a href-disabled="http://www.migrationobservatory.ox.ac.uk/briefings/migration-flows-a8-and-other-eu-migrants-and-uk" href-disabled-default-color="" href-disabled-underline="" href="http://www.migrationwatchuk.org/briefing-paper/364" target="_blank">Where did we get this from?</a>
            </div>
            <div class="fill-empty-space"></div>
            <div class="emoticon-div">
              <div class="how-emoticons-work">How does this make you feel?</div>
              <div class="emoticons-7">
                <img width="50" src="images/angry with word.png" data-ix="anger-selected-7" class="anger-7">
                <img width="50" src="images/surprised with word.png" data-ix="shock-selected-7" class="shock-7">
                <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-7" class="indifferent-7">
                <img width="50" src="images/happy with word.png" data-ix="happy-selected-7" class="happy-7">
                <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-7" class="delighted-7">
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-4 column-8">
        <div class="card-8">
          <div class="sticky-footer">
            <h1 class="card-header-8">Do they take our jobs?</h1>
            <h1 class="headline-fact-long">Yes as they compete in the same market as a UK citizen.</h1>
            <a href="#" data-ix="p8" class="w-button button-8">More info</a>
            <p data-ix="display-none-on-load" class="p8">Evidence of displacement of UK-born workers has been found by the Migration Advisory Committee. They reported that for every 100 non-EU migrants employed 23 UK born workers would have been displaced.</p>
            <div class="evidence"><a target="_blank" href="https://www.gov.uk/government/uploads/system/uploads/attachment_data/file/257235/analysis-of-the-impacts.pdf">Where did we get this from?</a>
            </div>
            <div class="fill-empty-space"></div>
            <div class="emoticon-div">
              <div class="how-emoticons-work">How does this make you feel?</div>
              <div class="emoticons-8">
                <img width="50" src="images/angry with word.png" data-ix="anger-selected-8" class="anger-8">
                <img width="50" src="images/surprised with word.png" data-ix="shock-selected-8" class="shock-8">
                <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-8" class="indifferent-8">
                <img width="50" src="images/happy with word.png" data-ix="happy-selected-8" class="happy-8">
                <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-8" class="delighted-8">
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-3 column-9">
        <div class="card-9">
          <div class="sticky-footer test">
            <h1 class="card-header-8">How many are looking for work?</h1>
            <h1 class="headline-fact">30.10%</h1>
            <a href="#" data-ix="p9" class="w-button button-9">More info</a>
            <p data-ix="display-none-on-load" class="p9">In the first quarter of 2015, 69.9% of non-UK born working-age migrants were in some kind of employment, compared with 74% of the UK-born. However, this represents a considerable increase from historically low levels of employment among migrants.</p>
            <div class="evidence"><a href-disabled="http://www.migrationobservatory.ox.ac.uk/briefings/migration-flows-a8-and-other-eu-migrants-and-uk" href-disabled-default-color="" href-disabled-underline="" href="http://www.migrationwatchuk.org/key-topics/employment-welfare" target="_blank">Where did we get this from?</a>
            </div>
            <div class="fill-empty-space"></div>
            <div class="emoticon-div">
              <div class="how-emoticons-work">How does this make you feel?</div>
              <div class="emoticons-9">
                <img width="50" src="images/angry with word.png" data-ix="anger-selected-9" class="anger-9">
                <img width="50" src="images/surprised with word.png" data-ix="shock-selected-9" class="shock-9">
                <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-9" class="indifferent-9">
                <img width="50" src="images/happy with word.png" data-ix="happy-selected-9" class="happy-9">
                <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-9" class="delighted-9">
              </div>
            </div>
          </div>
        </div>
        <div class="card-10">
          <div class="sticky-footer">
            <h1 class="card-header-8">Workers rights</h1>
            <h1 class="headline-fact-long">Same as a UK national</h1>
            <div class="fill-empty-space"></div>
            <div class="emoticon-div">
              <div class="how-emoticons-work">How does this make you feel?</div>
              <div class="emoticons-10">
                <img width="50" src="images/angry with word.png" data-ix="anger-selected-10" class="anger-10">
                <img width="50" src="images/surprised with word.png" data-ix="shock-selected-10" class="shock-10">
                <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-10" class="indifferent-10">
                <img width="50" src="images/happy with word.png" data-ix="happy-selected-10" class="happy-10">
                <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-10" class="delighted-10">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <a href="#Intro--start" data-ix="display-none-on-load" class="w-button back-to-top-2">Back To Top</a>
  </div>
  <div id="Section-3" class="w-section section-3">
    <h4 class="how-to-use-the-grid-header">What rights and responsibilities do migrants have?</h4>
    <img width="25" src="images/down arrow.svg" data-ix="drop-down-section-4" class="drop-down-topics">
    <div data-ix="display-none-on-load" class="w-row fourth-column-set">
      <div class="w-col w-col-5 column-10">
        <div class="card-11">
          <div class="sticky-footer">
            <h1 class="card-header-8">What can they can do?</h1>
            <h1 class="headline-fact-long">Pretty much everything a UK citizen can do&nbsp;</h1>
            <h1 class="headline-small">(apart from vote at a General Election or serve on a jury)</h1>
            <div class="evidence"><a href-disabled="http://www.migrationobservatory.ox.ac.uk/briefings/migration-flows-a8-and-other-eu-migrants-and-uk" href-disabled-default-color="" href-disabled-underline="" href="http://findlaw.co.uk/law/government/constitutional_law/do-i-have-to-do-jury-service.html" target="_blank">Where did we get this from?</a>
            </div>
            <div class="fill-empty-space"></div>
            <div class="emoticon-div">
              <div class="how-emoticons-work">How does this make you feel?</div>
              <div class="emoticons-11">
                <img width="50" src="images/angry with word.png" data-ix="anger-selected-11" class="anger-11">
                <img width="50" src="images/surprised with word.png" data-ix="shock-selected-11" class="shock-11">
                <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-11" class="indifferent-11">
                <img width="50" src="images/happy with word.png" data-ix="happy-selected-11" class="happy-11">
                <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-11" class="delighted-11">
              </div>
            </div>
          </div>
        </div>
        <div class="card-12">
          <div class="sticky-footer">
            <h1 class="card-header-8">Whose law do they abide by?</h1>
            <h1 class="headline-fact-long">Whichever country they reside in.</h1>
            <div class="fill-empty-space"></div>
            <div class="emoticon-div">
              <div class="how-emoticons-work">How does this make you feel?</div>
              <div class="emoticons-12">
                <img width="50" src="images/angry with word.png" data-ix="anger-selected-12" class="anger-12">
                <img width="50" src="images/surprised with word.png" data-ix="shock-selected-12" class="shock-12">
                <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-12" class="indifferent-12">
                <img width="50" src="images/happy with word.png" data-ix="happy-selected-12" class="happy-12">
                <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-12" class="delighted-12">
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-4 column-11">
        <div class="card-13">
          <div class="sticky-footer">
            <h1 class="card-header-8">Where are they sent to prison? At what cost?</h1>
            <h1 class="headline-fact-long">Depends on the crime.</h1>
            <a href="#" data-ix="p10" class="w-button button-11">More info</a>
            <p data-ix="display-none-on-load" class="p10">Generally speaking if a EU immigrant commits a crime in the UK they will serve their time in a prison in the UK if their sentance is less than 24 months (12 months or less for crimes related to drugs, sex, violence or other serious criminal activity) For those over 24 months the Home Office is likely to deport them to their country of origin for them to serve their sentance there. Foreign criminals make up approx. 14% of the overall prison population in the UK.</p>
            <div class="evidence"><a href-disabled="http://www.migrationobservatory.ox.ac.uk/briefings/migration-flows-a8-and-other-eu-migrants-and-uk" href-disabled-default-color="" href-disabled-underline="" href="https://www.justice.gov.uk/offenders/types-of-offender/foreign" target="_blank">Where did we get this from?</a>
            </div>
            <div class="fill-empty-space"></div>
            <div class="emoticon-div">
              <div class="how-emoticons-work">How does this make you feel?</div>
              <div class="emoticons-13">
                <img width="50" src="images/angry with word.png" data-ix="anger-selected-13" class="anger-13">
                <img width="50" src="images/surprised with word.png" data-ix="shock-selected-13" class="shock-13">
                <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-13" class="indifferent-13">
                <img width="50" src="images/happy with word.png" data-ix="happy-selected-13" class="happy-13">
                <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-13" class="delighted-13">
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-3 column-12">
        <div class="card-14">
          <div class="sticky-footer">
            <h1 class="card-header-8">Can they be removed from the country?</h1>
            <h1 class="headline-fact-long">Yes. Either via deportation or via a 'removal' letter.</h1>
            <a href="#" data-ix="p11" class="w-button button-12">More info</a>
            <p data-ix="display-none-on-load" class="p11">The Home Office is likely to begin deportation proceedings if you were sentenced toprison for 24 months or over for any offences, or to one year or more if the offenceis related to drugs, sex, violence or other serious criminal activity. The sentence mustrelate to one conviction. Sentences cannot be added together.However, an EU/EEA national who does not meet the above criteria but who theHome Office believes to be a 'low level persistent offender', a risk to public health, a risk to national security or a risk to the public can also be deported.</p>
            <div class="evidence"><a href-disabled="http://www.migrationobservatory.ox.ac.uk/briefings/migration-flows-a8-and-other-eu-migrants-and-uk" href-disabled-default-color="" href-disabled-underline="" href="http://www.biduk.org/sites/default/files/BID%20Factsheet%206%20Deportation%20Appeals%20Deportation%20of%20EU%20nationals_pdf%20version_0.pdf" target="_blank">Where did we get this from?</a>
            </div>
            <div class="fill-empty-space"></div>
            <div class="emoticon-div">
              <div class="how-emoticons-work">How does this make you feel?</div>
              <div class="emoticons-14">
                <img width="50" src="images/angry with word.png" data-ix="anger-selected-14" class="anger-14">
                <img width="50" src="images/surprised with word.png" data-ix="shock-selected-14" class="shock-14">
                <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-14" class="indifferent-14">
                <img width="50" src="images/happy with word.png" data-ix="happy-selected-14" class="happy-14">
                <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-14" class="delighted-14">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <a href="#Intro--start" data-ix="display-none-on-load" class="w-button back-to-top-3">Back To Top</a>
  </div>
  <div id="Section-4" class="w-section section-4">
    <h4 class="how-to-use-the-grid-header">Impact of migration on everyday life</h4>
    <img width="25" src="images/down arrow.svg" data-ix="drop-down-section-5" class="drop-down-topics">
    <div data-ix="display-none-on-load" class="w-row fifth-column-set">
      <div class="w-col w-col-5 column-13">
        <div class="card-15">
          <div class="sticky-footer">
            <h1 class="card-header-8">Impact on public services</h1>
            <h1 class="headline-fact-long">Mixed. Less likely to use social care and health services. More likely to use education and childcare.</h1>
            <a href="#" data-ix="p12" class="w-button button-13">More info</a>
            <p data-ix="display-none-on-load" class="p12">The extent to which migrants rely on public services will vary depending on the characteristics of migrants and on the service in question. For example, newly arriving migrants tend to be young adults. Because of their age, they are expected to be less likely to use adult social care and most health services than the UK born. However, they are more likely than the UK born to have young children, and so they are expected to rely more heavily on education and maternity care.</p>
            <div class="evidence"><a href-disabled="http://www.migrationobservatory.ox.ac.uk/briefings/migration-flows-a8-and-other-eu-migrants-and-uk" href-disabled-default-color="" href-disabled-underline="" href="http://www.migrationobservatory.ox.ac.uk/briefings/election-2015-briefing-impacts-migration-local-public-services" target="_blank">Where did we get this from?</a>
            </div>
            <div class="fill-empty-space"></div>
            <div class="emoticon-div">
              <div class="how-emoticons-work">How does this make you feel?</div>
              <div class="emoticons-15">
                <img width="50" src="images/angry with word.png" data-ix="anger-selected-15" class="anger-15">
                <img width="50" src="images/surprised with word.png" data-ix="shock-selected-15" class="shock-15">
                <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-15" class="indifferent-15">
                <img width="50" src="images/happy with word.png" data-ix="happy-selected-15" class="happy-15">
                <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-15" class="delighted-15">
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-4 column-14">
        <div class="card-16">
          <div class="sticky-footer">
            <h1 class="card-header-8">Impact on housing</h1>
            <h1 class="headline-fact-long">Migrants mainly rent houses.</h1>
            <a href="#" data-ix="p13" class="w-button button-14">More info</a>
            <p data-ix="display-none-on-load" class="p13">Evidence suggests that immigration decreases house prices in England and Wales. Estimates suggest that a 1% increase in the migrant share the population in an area reduces house prices by almost 2%. In addition UK-born individuals and foreign-born individuals have similar levels of participation in social housing.</p>
            <div class="evidence"><a href-disabled="http://www.migrationobservatory.ox.ac.uk/briefings/migration-flows-a8-and-other-eu-migrants-and-uk" href-disabled-default-color="" href-disabled-underline="" href="http://www.migrationobservatory.ox.ac.uk/briefings/migrants-and-housing-uk-experiences-and-impacts" target="_blank">Where did we get this from?</a>
            </div>
            <div class="fill-empty-space"></div>
            <div class="emoticon-div">
              <div class="how-emoticons-work">How does this make you feel?</div>
              <div class="emoticons-16">
                <img width="50" src="images/angry with word.png" data-ix="anger-selected-16" class="anger-16">
                <img width="50" src="images/surprised with word.png" data-ix="shock-selected-16" class="shock-16">
                <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-16" class="indifferent-16">
                <img width="50" src="images/happy with word.png" data-ix="happy-selected-16" class="happy-16">
                <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-16" class="delighted-16">
              </div>
            </div>
          </div>
        </div>
        <div class="card-17">
          <div class="sticky-footer">
            <h1 class="card-header-8">Claiming government support.</h1>
            <h1 class="headline-fact large-text">Mixed outcomes.</h1>
            <a href="#" data-ix="p14" class="w-button button-16">More info</a>
            <p data-ix="display-none-on-load" class="p14">The fiscal impact of migration in the UK is small and differs by migrant group (e.g. EEA migrants vs. non-EEA migrants, recent migrants vs. all migrants) In theory, the fiscal effects of immigration largely depend on migrants’ characteristics (skills, age, length of stay), their impacts on the labour market and welfare entitlements</p>
            <div class="evidence"><a target="_blank" href="http://www.migrationobservatory.ox.ac.uk/briefings/fiscal-impact-immigration-uk">Where did we get this from?</a>
            </div>
            <div class="fill-empty-space"></div>
            <div class="emoticon-div">
              <div class="how-emoticons-work">How does this make you feel?</div>
              <div class="emoticons-17">
                <img width="50" src="images/angry with word.png" data-ix="anger-selected-17" class="anger-17">
                <img width="50" src="images/surprised with word.png" data-ix="shock-selected-17" class="shock-17">
                <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-17" class="indifferent-17">
                <img width="50" src="images/happy with word.png" data-ix="happy-selected-17" class="happy-17">
                <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-17" class="delighted-17">
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-3 column-15">
        <div class="card-18">
          <div class="sticky-footer">
            <h1 class="card-header-8">Impact on Crime</h1>
            <h1 class="headline-fact-long">Little or no impact.</h1>
            <a href="#" data-ix="p15" class="w-button button-15">More info</a>
            <p data-ix="display-none-on-load" class="p15">A continuous reduction in overall &nbsp;crimes in England and Wales since 2002 corresponded with a rising foreign-born population, but there is no evidence to suggest that rising migration caused this decline in crime rates.</p>
            <div class="evidence"><a target="_blank" href="http://www.migrationobservatory.ox.ac.uk/briefings/immigration-and-crime-evidence-uk-and-other-countries">Where did we get this from?</a>
            </div>
            <div class="fill-empty-space"></div>
            <div class="emoticon-div">
              <div class="how-emoticons-work">How does this make you feel?</div>
              <div class="emoticons-18">
                <img width="50" src="images/angry with word.png" data-ix="anger-selected-18" class="anger-18">
                <img width="50" src="images/surprised with word.png" data-ix="shock-selected-18" class="shock-18">
                <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-18" class="indifferent-18">
                <img width="50" src="images/happy with word.png" data-ix="happy-selected-18" class="happy-18">
                <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-18" class="delighted-18">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <a href="#Intro--start" data-ix="display-none-on-load" class="w-button back-to-top-4">Back To Top</a>
  </div>
  <div class="w-section got-the-basics topics">
    <h1 class="basics-link">Thats immigration done for now</h1>
    <p class="lets-get-started-pap">You've now done all that you'd like to for the topic of immigration, up next we'll be moving onto Sovereignty and Law making.
      <br>
      <br>Remember you dont have to react to every card, feel free to pick and choose what topics and cards you look at.</p>
    <a href="sovereignty-and-the-law.php" class="w-button continue-button">Next topic &gt;</a>
    <a href="resultspage%201.php" class="w-button continue-button">Immigration results &gt;</a>
  </div>
  
  <!-- footer -->
  
  <div id="contact" class="w-section footer">
    <div class="w-row about-us">
      <div class="w-col w-col-4 our-pages">
        <h4 class="about-us-heading">Our Pages</h4>
        <div data-collapse="none" data-animation="default" data-duration="400" data-contain="1" class="w-nav footer-nav">
          <div class="w-container">
            <nav role="navigation" class="w-nav-menu">
              <a href="new-homepage.php" class="w-nav-link footer-page">Home</a>
              <a href="about-us.php" class="w-nav-link footer-page">About Us</a>
              <a href="the-black-and-white.php" class="w-nav-link footer-page">The Black &amp; White</a>
            </nav>
            <div class="w-nav-button">
              <div class="w-icon-nav-menu"></div>
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-4 about-us-block">
        <h4 class="about-us-heading">About Us</h4>
        <p>Designed with love at Exeter University
          <br>
          <br>Innovation Centre
          <br>Rennes Drive
          <br>EX4 4RN</p>
      </div>
      <div class="w-col w-col-4 get-in-touch">
        <h4 class="about-us-heading">Get in touch</h4>
        <p>Want to say hi? &nbsp; hello@leaveorstay.co.uk</p>
        <div class="make-twitter-central">
          <div class="w-widget w-widget-twitter twitter">
            <iframe src="https://platform.twitter.com/widgets/follow_button.html#screen_name=leaveorstayHQ&amp;show_count=false&amp;size=m&amp;show_screen_name=true&amp;dnt=true" scrolling="no" frameborder="0" allowtransparency="true" style="border: none; overflow: hidden; width: 100%; height: 21px;"></iframe>
          </div>
        </div>
        <div class="w-widget w-widget-facebook facebook">
          <iframe src="https://www.facebook.com/plugins/like.php?href=http%3A%2F%2Ffacebook.com%2FleaveorstayHQ&amp;layout=box_count&amp;locale=en_US&amp;action=like&amp;show_faces=false&amp;share=false" scrolling="no" frameborder="0" allowtransparency="true" style="border: none; overflow: hidden; width: 55px; height: 65px;"></iframe>
        </div>
      </div>
    </div>
  </div>
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <script type="text/javascript" src="js/webflow.js"></script>
  <!--[if lte IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/placeholders/3.0.2/placeholders.min.js"></script><![endif]-->
</body>
</html>