<!DOCTYPE html>
<!-- Last Published: Sun May 01 2016 23:29:54 GMT+0000 (UTC) -->
<html data-wf-site="56fd24aaaea6500c763220cf" data-wf-page="56fd24aaaea6500c763220d2">
<head>
  <meta charset="utf-8">
  <title>leaveorstay which way should I vote in the EU referendum? Brexit</title>
  <meta name="description" content="Should we leave or stay in the EU.  We provide accurate, impartial information on the referendum so that you can cast an informed vote.">
  <meta property="og:title" content="leaveorstay.co.uk">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/normalize.css">
  <link rel="stylesheet" type="text/css" href="css/webflow.css">
  <link rel="stylesheet" type="text/css" href="css/los-template.webflow.css">
  <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.4.7/webfont.js"></script>
  <script>
    WebFont.load({
        google: {
          families: ["Open Sans:300,300italic,400,400italic,600,600italic,700,700italic,800,800italic","Varela Round:400","Ubuntu:300,300italic,400,400italic,500,500italic,700,700italic","Lato:100,100italic,300,300italic,400,400italic,700,700italic,900,900italic","Montserrat:400,700","Raleway:100,200,300,regular,500,600,700,800,900"]
        }
      });
  </script>
  <script type="text/javascript" src="js/modernizr.js"></script>
  <link rel="shortcut icon" type="image/x-icon" href="images/Favicon.png">
  <link rel="apple-touch-icon" href="https://daks2k3a4ib2z.cloudfront.net/img/webclip.png">
  <script type="text/javascript">
    var _gaq = _gaq || [];
      _gaq.push(['_setAccount', 'UA-76346760-1'], ['_trackPageview']);
      (function() {
        var ga = document.createElement('script');
        ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
      })();
  </script>
</head>
<body>
  <div data-collapse="medium" data-animation="default" data-duration="400" data-contain="1" class="w-nav navbar">
    <div class="w-container">
      <a href="new-homepage.php" class="w-nav-brand logo-container">
        <h1 class="logo-text"><strong>leave</strong>or<strong>stay</strong>.co.uk</h1>
      </a>
      <nav role="navigation" class="w-nav-menu">
        <a href="immigration.php" class="w-nav-link nav-link">Immigration</a>
        <a href="sovereignty-and-the-law.php" class="w-nav-link nav-link">Sovereignty</a>
        <a href="trade.php" class="w-nav-link nav-link">Trade</a>
        <a href="jobs.php" class="w-nav-link nav-link">Jobs</a>
        <a href="defence.php" class="w-nav-link nav-link">Defense</a>
        <a href="signup.php" class="w-button hero-button">Sign up/login</a>
      </nav>
      <div class="w-nav-button menu">
        <div class="w-icon-nav-menu"></div>
      </div>
    </div>
  </div>
  <div class="w-section hero homepage">
    <div class="hero-overlay homepage">
      <div class="w-container hero-container homepage">
        <div class="hero-text-block homepage">
          <h1 data-ix="hero-title" class="hero-title">the uk and the eu as it is today.</h1>
          <h1 data-ix="hero-title-2" class="hero-title word">the good.<br>the bad.<br>the ugly.</h1>
          <h1 data-ix="hero-title-6" class="hero-title title-2">We're the neutral platform <br>giving you both sides of the&nbsp;<strong>EU referendum</strong> debate.<br><br>IMPARTIAL.<br>Honest.<br>Personal.</h1>
          <div class="hero-buttons-wrapper">
            <a href="#about-us" data-ix="hero-button" class="hero-button homepage">Learn more</a>
            <a href="contact.php" data-ix="hero-button-2" class="hero-button _2">get access first</a>
          </div>
        </div>
        <img src="images/los home header.png" class="hero-image macbook">
      </div>
    </div>
  </div>
  <div class="home-page-reasons">
    <div id="3-reasons" class="image-section-overlay">
      <div class="w-container container">
        <div class="section-title-block centered">
          <h2 class="section-title">3 reasons why we need leaveorstay</h2>
          <h2 class="section-title subtitle">are you ready for June 23rd?</h2>
          <div class="section-divider-line"></div>
        </div>
        <div class="w-row features-row">
          <div class="w-col w-col-4 feature-column">
            <div class="feature-block">
              <h2 class="feature-title">16%</h2>
              <h2 class="feature-title subtitle">of the electorate felt 'informed' about the referendum</h2>
              <div class="section-divider-line feature-divider"></div>
              <p>With so few voters being given the information they need to cast an informed vote, no wonder so many people are giving up and becoming 'disinterested'.</p>
            </div>
          </div>
          <div class="w-col w-col-4 feature-column">
            <div class="feature-block">
              <h2 class="feature-title">£20 million +</h2>
              <h2 class="feature-title subtitle">will be spent trying to influence us one way or &nbsp;another</h2>
              <div class="section-divider-line feature-divider"></div>
              <p>We think voters deserve a debate that is informed by the facts and shows both sides of the argument in a way that makes sense and is balanced.</p>
            </div>
          </div>
          <div class="w-col w-col-4 feature-column last">
            <div class="feature-block">
              <h2 class="feature-title">no 'right' answer</h2>
              <h2 class="feature-title subtitle">it's not possible. no one really knows what will happen.</h2>
              <div class="section-divider-line feature-divider"></div>
              <p>Regardless of what is said and done there is no such thing as a 'right' answer. We just want to make sure that as many voters as possible &nbsp;walk into the voting booth knowing what's going on.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div id="about-us" class="w-section how-does-it-work">
    <h1 class="home-header">What is leaveorstay?</h1>
    <div class="w-container container centered">
      <div class="w-row intro-row">
        <div class="w-col w-col-4 intro-column">
          <img src="images/Icon-speech.png" class="intro-icon">
          <h2 class="intro-column-title">A complete picture</h2>
          <h2 class="intro-column-title subtitle">in one place</h2>
          <p class="paragraph _2">Evidenced and easily understandable facts to help inform and shape the debate. No spin, no hidden agenda, just the facts as they are.
            <br>
            <br> Everything we post has been checked and re-checked.</p>
        </div>
        <div class="w-col w-col-4 intro-column">
          <img src="images/Icon-lock.png" class="intro-icon">
          <h2 class="intro-column-title">100% private</h2>
          <h2 class="intro-column-title subtitle">A space to decide</h2>
          <p class="paragraph _2">Free from ads, friends opinions and the press, all of which just keep making the decision harder.
            <br>
            <br>This is your space to decide your way.</p>
        </div>
        <div class="w-col w-col-4 intro-column last">
          <img src="images/Icon-stats.png" class="intro-icon">
          <h2 class="intro-column-title">&nbsp;react</h2>
          <h2 class="intro-column-title subtitle">to what you read</h2>
          <p class="paragraph _2">Let us know how you feel using our five emoticons and we'll summarise how you think and feel about the EU and what you can do next.
            <br>
            <br>We'll give you all the options on the table.</p>
        </div>
      </div>
      <div class="intro-button-wrapper">
        <div class="intro-button-line"></div>
        <a href="the-black-and-white.php" class="button intro-button">See it in action &gt;</a>
      </div>
    </div>
  </div>
  <div class="w-section image-section">
    <div id="fix" class="image-section-overlay">
      <div class="w-container container">
        <div class="w-row _2-column-row">
          <div class="w-col w-col-6 w-hidden-small w-hidden-tiny">
            <img src="images/los how it works.png" class="how-itworks">
          </div>
          <div class="w-col w-col-6 checklist-column-right">
            <div class="column-title-block">
              <h2 class="column-title"><strong class="how-it-works">how does it work?</strong></h2>
              <h5 class="column-title subtitle">We'll&nbsp;inform, challenge&nbsp;and support you.</h5>
              <div class="section-divider-line"></div>
            </div>
            <div class="checklist-title"><strong>Fed up and confused with the debate as it is?</strong>
            </div>
            <p class="paragraph">leaveorstay is all about making sure that we have an informed debate. We believe that everyone is entitled to their own opinion, but not to their own facts. So if you're just getting started, confused and fed up or want a fresh perspective that treats each side equally then this is the platfrom for you.
              <br>
              <br>Here's what leaveorstay can do for you:</p>
            <ul class="w-list-unstyled check-list">
              <li data-ix="fade-on-scroll-right" class="w-clearfix check-list-item">
                <img src="images/Icon-check.png" class="check-list-icon">
                <div class="checklist-title">Facts drawn from identifable sources, fully evidenced and traceable.</div>
              </li>
              <li data-ix="fade-on-scroll-right" class="w-clearfix check-list-item">
                <img src="images/Icon-check.png" class="check-list-icon">
                <div class="checklist-title"><strong>Both sides of the argument summarised perfectly.</strong>
                </div>
              </li>
              <li data-ix="fade-on-scroll-right" class="w-clearfix check-list-item">
                <img src="images/Icon-check.png" class="check-list-icon">
                <div class="checklist-title">Each side of the argument broken down into easily understandable topics that make sense.</div>
              </li>
              <li data-ix="fade-on-scroll-right" class="w-clearfix check-list-item">
                <img src="images/Icon-check.png" class="check-list-icon">
                <div class="checklist-title"><strong>Available on your mobile, tablet or laptop.</strong>
                </div>
              </li>
              <li data-ix="fade-on-scroll-right" class="w-clearfix check-list-item">
                <img src="images/Icon-check.png" class="check-list-icon">
                <div class="checklist-title">Free from personalities and party bickering, just the facts and arguments you need to cast an informed vote.</div>
              </li>
              <li data-ix="fade-on-scroll-right" class="w-clearfix check-list-item">
                <img src="images/Icon-check.png" class="check-list-icon">
                <div class="checklist-title"><strong>Updated daily with fresh content</strong>
                </div>
              </li>
              <li data-ix="fade-on-scroll-right" class="w-clearfix check-list-item last">
                <img src="images/Icon-check.png" class="check-list-icon">
                <div class="checklist-title"><strong>Completley free to use.</strong>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="w-section results-section products">
    <div class="w-container container">
      <div class="models-text-block">
        <h2 class="large-column-title">what we're<br>covering</h2>
        <div class="section-divider-line models-divider"></div>
        <p>The EU is complex. Making an informed decision doesn't have to be. Here are some of the topics we have lined up for leaveorstay.</p>
        <a href="the-black-and-white.php" class="button intro-button">See it in action &gt;</a>
      </div>
      <div data-animation="slide" data-duration="500" data-infinite="1" data-delay="3000" data-autoplay="1" class="w-slider models-slider">
        <div class="w-slider-mask">
          <div class="w-slide models-slide">
            <img height="100" src="images/immigration icon.png" class="model-image">
            <h5 data-ix="model-title-slide" class="model-slider-title">Immigration</h5>
            <h5 data-ix="model-title-slide-2" class="model-slider-title subtitle">Benefits, costs and what it means for you</h5>
          </div>
          <div class="w-slide models-slide">
            <img src="images/economy icon final.png" class="model-image ipad">
            <h5 data-ix="model-title-slide" class="model-slider-title">Economy</h5>
            <h5 data-ix="model-title-slide-2" class="model-slider-title subtitle">What are the risks and rewards?</h5>
          </div>
          <div class="w-slide models-slide">
            <img src="images/law icon.png" class="model-image iphone">
            <h5 data-ix="model-title-slide" class="model-slider-title">Laws</h5>
            <h5 data-ix="model-title-slide-2" class="model-slider-title subtitle">Who makes our laws?</h5>
          </div>
        </div>
        <div class="w-slider-arrow-left model-slider-arrow">
          <div class="w-icon-slider-left"></div>
        </div>
        <div class="w-slider-arrow-right model-slider-arrow">
          <div class="w-icon-slider-right"></div>
        </div>
        <div class="w-slider-nav w-round w-hidden-main w-hidden-medium w-hidden-small w-hidden-tiny"></div>
      </div>
    </div>
  </div>
  <div class="w-section results-section">
    <div class="w-container container centered">
      <div class="section-title-block centered">
        <h2 class="cta-topic-page">&nbsp;Want to be the first to know when we go live?</h2>
      </div>
      <a href="contact.php" class="button intro-button">Sign up for early access</a>
    </div>
  </div>
  <div id="About-Us" class="w-section results-section tint">
    <div class="w-container container">
      <div class="w-row">
        <div data-ix="fade-on-scroll" class="w-col w-col-6 info-column-left">
          <div class="section-title-block">
            <h2 class="section-title">About us</h2>
            <h2 class="section-title subtitle">why are we doing this?</h2>
            <div class="section-divider-line"></div>
          </div>
          <p class="paragraph _2">We believe that the most important thing in a democracy is a well informed electorate. We think that the way in which we make decisions about elections is broken. From lack of clear information to personalities dominating the media, this is an attempt at helping fix it.</p>
        </div>
        <div class="w-col w-col-6 w-hidden-small w-hidden-tiny emoticon-colum"></div>
      </div>
      <img src="images/about us emoticons.png" class="info-image">
    </div>
  </div>
  <div id="contact" class="w-section footer">
    <div class="w-row about-us">
      <div class="w-col w-col-4 our-pages">
        <h4 class="about-us-heading">Our Pages</h4>
        <div data-collapse="none" data-animation="default" data-duration="400" data-contain="1" class="w-nav footer-nav">
          <div class="w-container">
            <nav role="navigation" class="w-nav-menu">
              <a href="new-homepage.php" class="w-nav-link footer-page">Home</a>
              <a href="about-us.php" class="w-nav-link footer-page">About Us</a>
              <a href="the-black-and-white.php" class="w-nav-link footer-page">The Black &amp; White</a>
            </nav>
            <div class="w-nav-button">
              <div class="w-icon-nav-menu"></div>
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-4 about-us-block">
        <h4 class="about-us-heading">About Us</h4>
        <p>Designed with love at Exeter University
          <br>
          <br>Innovation Centre
          <br>Rennes Drive
          <br>EX4 4RN</p>
      </div>
      <div class="w-col w-col-4 get-in-touch">
        <h4 class="about-us-heading">Get in touch</h4>
        <p>Want to say hi? &nbsp; hello@leaveorstay.co.uk</p>
        <div class="make-twitter-central">
          <div class="w-widget w-widget-twitter twitter">
            <iframe src="https://platform.twitter.com/widgets/follow_button.html#screen_name=leaveorstayHQ&amp;show_count=false&amp;size=m&amp;show_screen_name=true&amp;dnt=true" scrolling="no" frameborder="0" allowtransparency="true" style="border: none; overflow: hidden; width: 100%; height: 21px;"></iframe>
          </div>
        </div>
        <div class="w-widget w-widget-facebook facebook">
          <iframe src="https://www.facebook.com/plugins/like.php?href=http%3A%2F%2Ffacebook.com%2FleaveorstayHQ&amp;layout=box_count&amp;locale=en_US&amp;action=like&amp;show_faces=false&amp;share=false" scrolling="no" frameborder="0" allowtransparency="true" style="border: none; overflow: hidden; width: 55px; height: 65px;"></iframe>
        </div>
      </div>
    </div>
  </div>
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <script type="text/javascript" src="js/webflow.js"></script>
  <!--[if lte IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/placeholders/3.0.2/placeholders.min.js"></script><![endif]-->
</body>
</html>