<!DOCTYPE html>
<!-- Last Published: Sun May 01 2016 23:29:54 GMT+0000 (UTC) -->
<html data-wf-site="56fd24aaaea6500c763220cf" data-wf-page="571a7c346698e01d643b0072">
<head>
  <meta charset="utf-8">
  <title>Sovereignty and the law</title>
  <meta name="description" content="Should we leave or stay in the EU.  We provide accurate, impartial information on the referendum so that you can cast an informed vote.">
  <meta property="og:title" content="Sovereignty and the law">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/normalize.css">
  <link rel="stylesheet" type="text/css" href="css/webflow.css">
  <link rel="stylesheet" type="text/css" href="css/los-template.webflow.css">
  <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.4.7/webfont.js"></script>
  <script>
    WebFont.load({
        google: {
          families: ["Open Sans:300,300italic,400,400italic,600,600italic,700,700italic,800,800italic","Varela Round:400","Ubuntu:300,300italic,400,400italic,500,500italic,700,700italic","Lato:100,100italic,300,300italic,400,400italic,700,700italic,900,900italic","Montserrat:400,700","Raleway:100,200,300,regular,500,600,700,800,900"]
        }
      });
  </script>
  <script type="text/javascript" src="js/modernizr.js"></script>
  <link rel="shortcut icon" type="image/x-icon" href="images/Favicon.png">
  <link rel="apple-touch-icon" href="https://daks2k3a4ib2z.cloudfront.net/img/webclip.png">
  <script type="text/javascript">
    var _gaq = _gaq || [];
      _gaq.push(['_setAccount', 'UA-76346760-1'], ['_trackPageview']);
      (function() {
        var ga = document.createElement('script');
        ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
      })();
  </script>
</head>
<body class="body topics">
  <div data-collapse="medium" data-animation="default" data-duration="400" data-contain="1" class="w-nav navbar">
    <div class="w-container">
      <a href="new-homepage.php" class="w-nav-brand logo-container">
        <h1 class="logo-text"><strong>leave</strong>or<strong>stay</strong>.co.uk</h1>
      </a>
      <nav role="navigation" class="w-nav-menu">
        <a href="immigration.php" class="w-nav-link nav-link">Immigration</a>
        <a href="sovereignty-and-the-law.php" class="w-nav-link nav-link">Sovereignty</a>
        <a href="trade.php" class="w-nav-link nav-link">Trade</a>
        <a href="jobs.php" class="w-nav-link nav-link">Jobs</a>
        <a href="defence.php" class="w-nav-link nav-link">Defense</a>
        <a href="signup.php" class="w-button hero-button">Sign up/login</a>
      </nav>
      <div class="w-nav-button menu">
        <div class="w-icon-nav-menu"></div>
      </div>
    </div>
  </div>
  <div class="w-section hero">
    <div class="hero-overlay immigration">
      <div class="w-container hero-container sovereignty">
        <h1 class="hero-title word">sovereignty &amp;<br>the law.</h1>
        <h1 class="hero-title">Question indlude:</h1>
        <h1 class="hero-title title-2">Does the EU "make" UK law?<br>Is EU law superior to UK law?<br>Is the EU run by "unelected bureaucrats"?</h1>
        <img src="images/sov-01.png" class="hero-image">
        <a href="#top" class="w-button hero-button">start topic</a>
        <a href="trade.php" class="w-button hero-button _2">Skip this topic</a>
      </div>
    </div>
  </div>
  <div id="top" class="w-section intro-panel">
    <h1 class="grid-header">Overview - What's the story with <strong>Sovereignty and law making:</strong></h1>
    <p class="overview-subtitle">This topic is all about which legal and political structures the UK sits in. The UK does have a fair portion of its laws influenced by Brussels and is required by EU law to adhere to them. The EU is considered by many leading experts to be amongst the most democratic international bodies in the world think UN, NATO, IMF etc. as citizens can directly impact it via votes. The main theme running through this topic is whether the UK should govern itself on everything and not be part of any form of larger union or whether it should transfer all power back to Westminster. Please note: The UK will not retain complete sovereignty even in the result of a vote to leave. Westminster is influenced by "unelected" bodies constantly like the House of Lords, NATO and lobbyists. Will the UK regain noticeable power? Yes. Will it regain all its power? No.</p>
    <div class="learn-how-to-use">How does this work?</div>
    <div class="drop">
      <div class="arrow-instruction">Every time you see this arrow, click it.</div>
      <img width="40" src="images/down arrow.svg" data-ix="drop-how-to" class="down-arrow">
    </div>
    <p data-ix="display-none-on-load" class="overview-dropdown">This is over 500 hrs worth of research condensed into about 5 minutes worth of clear, concise, quality reading. Each question has been researched, scrutinised and then made available to you in one place, all so you can make a more informed decision, faster.</p>
    <div data-ix="display-none-on-load" class="w-row how-to-row">
      <div class="w-col w-col-4 read">
        <h3 class="read-heading">1. Read</h3>
        <img height="100" src="images/immigration icon.png">
        <p class="read-para-1">Have a glance over the tiles below and get an understanding of what is going on with the EU and UK today.</p>
      </div>
      <div class="w-col w-col-4 react">
        <h3 class="react-heading">2. React</h3>
        <img height="100" src="images/happy without word.png">
        <p class="read-para">Use the 5 emojis to react to how you feel about the information you read.</p>
      </div>
      <div class="w-col w-col-4 impact">
        <h3 class="impact-heading">3. Impact</h3>
        <img height="100" src="images/Icon-check.png">
        <p class="read-para">We'll then use some clever computing to give you all the options on the table so you can decide what happens next.</p>
      </div>
    </div>
  </div>
  <div class="w-section tb-slider-section">
    <h1 class="topic-header">Top questions on Sovereignty &amp; the law</h1>
    <div data-animation="slide" data-duration="500" data-infinite="1" class="w-slider tb-slider">
      <div class="w-slider-mask tb-mask">
        <div class="w-slide slide-1">
          <div class="w-container container-tb">
            <div class="key-point-1 too-high">
              <h1 class="card-1-header">Is EU law superior to UK law?</h1>
              <p class="card-text">' EU law is superior to UK law. This stops the British public from being able to vote out those who make our laws'</p>
              <a href="#" data-ix="show-overview-1" class="w-button show-overview-1">Click to find out</a>
            </div>
          </div>
        </div>
        <div class="w-slide slide-2">
          <div class="w-container container-tb">
            <div class="key-point-2 too-high">
              <h1 class="card-2-header">Does the EU makes our laws?</h1>
              <p class="card-text">'The European Union makes two thirds of UK law.'</p>
              <a href="#" data-ix="show-overview-2" class="w-button show-overview-2">Click to find out</a>
            </div>
          </div>
        </div>
        <div class="w-slide slide-3">
          <div class="w-container container-tb">
            <div class="key-point-3 too-high">
              <h1 class="why-people-card-header">The ECHR stops us deporting criminals</h1>
              <p class="card-text">The EU stops us deporting criminals and terrorists as it may be against their human rights.</p>
              <a href="#" data-ix="show-overview-3" class="w-button show-overview-3">click to find out</a>
            </div>
          </div>
        </div>
      </div>
      <div data-ix="overview-hide" class="w-slider-arrow-left">
        <div class="w-icon-slider-left left-arrow"></div>
        <div class="next">Next Card</div>
      </div>
      <div data-ix="overview-hide" class="w-slider-arrow-right">
        <div class="w-icon-slider-right right-arrow"></div>
        <div class="next">Next Card</div>
      </div>
      <div class="w-slider-nav w-round slider-1-nav"></div>
    </div>
  </div>
  <div class="w-section argument-section">
    <div data-ix="display-none-on-load" class="w-row argument-row">
      <div class="w-col w-col-4 overview-1">
        <div class="sticky-footer">
          <h1 class="overview-heading">Overview&nbsp;</h1>
          <p class="basics-paragraph">Every position within the EU is voted upon (bar one where each country takes it in turns) but NOT directly. Instead the people we elect through the General Election and European Election represent us at the EU or they in turn vote for someone to represent them.
            <br>
            <br>The UK Parliament &nbsp;has the right to make whatever laws it pleases, even if such laws conflict with EU law. But, as a matter of EU and international law, doing so may place the UK as a State in breach of its obligations under the EU Treaties. The upshot is that, for as long as the UK remains a Member State of the EU, parliamentary sovereignty still&nbsp;exists, but it is unlawful—as a matter of EU and international law—for sovereignty to be&nbsp;exercised&nbsp;in ways that are incompatible with EU law.</p>
          <div class="fill-empty-space"></div>
          <div class="emoticon-div">
            <div class="how-emoticons-work">How does this make you feel?</div>
            <div class="emoticons-19">
              <img width="50" src="images/angry with word.png" data-ix="anger-selected-19" class="anger-19">
              <img width="50" src="images/surprised with word.png" data-ix="shock-selected-19" class="shock-19">
              <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-19" class="indifferent-19">
              <img width="50" src="images/happy with word.png" data-ix="happy-selected-19" class="happy-19">
              <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-19" class="delighted-19">
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-4 leave-1">
        <div class="sticky-footer">
          <h1 class="leave-heading">Impact if we leave</h1>
          <p class="basics-paragraph"><span style="font-size: 18px; background-color: rgb(227, 16, 100);"><strong class="impact-answer-leave">Severe.</strong></span>
            <br>
            <br>Depending on how the negotiations played out in the result of a UK exit, UK law would become 'supreme' law meaning that no other law could overrule it as it currently can.
            <br>
            <br> However the UK may have to accept some EU law as part of trading agreements and the UK would still be bound to other legal acts such as declaring war as part of NATO.</p>
          <div class="fill-empty-space"></div>
          <div class="emoticon-div">
            <div class="how-emoticons-work">How does this make you feel?</div>
            <div class="emoticons-20">
              <img width="50" src="images/angry with word.png" data-ix="anger-selected-20" class="anger-20">
              <img width="50" src="images/surprised with word.png" data-ix="shock-selected-20" class="shock-20">
              <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-20" class="indifferent-20">
              <img width="50" src="images/happy with word.png" data-ix="happy-selected-20" class="happy-20">
              <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-20" class="delighted-20">
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-4 stay-1">
        <div class="sticky-footer">
          <h1 class="stay-heading">Impact if we stay</h1>
          <p class="basics-paragraph"><strong class="impact-answer-stay">Unknown.</strong>&nbsp;
            <br>
            <br>The UK would still be bound by EU law but would most likely continue to opt out of certain legislation including monetary union (the Euro) and the border free area (Schengen).
            <br>
            <br>Note: The vast majority of EU law is not "primary" law meaning acts that directly impact things like the NHS and schools. The majority of the law is based around ensuring that people, goods and services are treated fairly across the EU.</p>
          <div class="fill-empty-space"></div>
          <div class="emoticon-div">
            <div class="how-emoticons-work">How does this make you feel?</div>
            <div class="emoticons-21">
              <img width="50" src="images/angry with word.png" data-ix="anger-selected-21" class="anger-21">
              <img width="50" src="images/surprised with word.png" data-ix="shock-selected-21" class="shock-21">
              <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-21" class="indifferent-21">
              <img width="50" src="images/happy with word.png" data-ix="happy-selected-21" class="happy-21">
              <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-21" class="delighted-21">
            </div>
          </div>
        </div>
      </div>
    </div>
    <div data-ix="display-none-on-load" class="w-row argument-row-2">
      <div class="w-col w-col-4 overview-2">
        <div class="sticky-footer">
          <h1 class="overview-heading">Overview&nbsp;</h1>
          <p class="basics-paragraph">That's about right if you count EU regulations as part of 'UK law'. The EU influence on&nbsp;UK-only laws is about 13%. But this counting exercise doesn't tell us very much.
            <br>
            <br>We may all be equal before the law, but not all laws are created equal; it's hard to say that an EU regulation on the&nbsp;methods of olive oil analysis&nbsp;is as important as an&nbsp;Act of Parliament restructuring the NHS.</p>
          <div class="fill-empty-space"></div>
          <div class="emoticon-div">
            <div class="how-emoticons-work">How does this make you feel?</div>
            <div class="emoticons-22">
              <img width="50" src="images/angry with word.png" data-ix="anger-selected-22" class="anger-22">
              <img width="50" src="images/surprised with word.png" data-ix="shock-selected-22" class="shock-22">
              <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-22" class="indifferent-22">
              <img width="50" src="images/happy with word.png" data-ix="happy-selected-22" class="happy-22">
              <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-22" class="delighted-22">
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-4 leave-2">
        <div class="sticky-footer">
          <h1 class="leave-heading">Impact if we leave</h1>
          <p class="basics-paragraph"><strong class="impact-answer-leave">Severe.</strong>
            <br>
            <br> The UK would be able to ensure that all the laws that it makes are voted upon only in Westminster by our directly elected MPs.
            <br>
            <br>However, as part of the negotiation process the UK may have to adhere to certain EU laws to access the single market as well as abide by international laws which are also set by people that we don't directly elect.</p>
          <div class="fill-empty-space"></div>
          <div class="emoticon-div">
            <div class="how-emoticons-work">How does this make you feel?</div>
            <div class="emoticons-23">
              <img width="50" src="images/angry with word.png" data-ix="anger-selected-23" class="anger-23">
              <img width="50" src="images/surprised with word.png" data-ix="shock-selected-23" class="shock-23">
              <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-23" class="indifferent-23">
              <img width="50" src="images/happy with word.png" data-ix="happy-selected-23" class="happy-23">
              <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-23" class="delighted-23">
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-4 stay-2">
        <div class="sticky-footer">
          <h1 class="stay-heading">Impact if we stay</h1>
          <p class="basics-paragraph"><strong class="impact-answer-stay">Minimal.</strong>&nbsp;
            <br>
            <br>The UK would continue to abide by EU laws and would continue to work within the EU to develop legislation that can have both a positive and a negative impact on the country.</p>
          <div class="fill-empty-space"></div>
          <div class="emoticon-div">
            <div class="how-emoticons-work">How does this make you feel?</div>
            <div class="emoticons-24">
              <img width="50" src="images/angry with word.png" data-ix="anger-selected-24" class="anger-24">
              <img width="50" src="images/surprised with word.png" data-ix="shock-selected-24" class="shock-24">
              <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-24" class="indifferent-24">
              <img width="50" src="images/happy with word.png" data-ix="happy-selected-24" class="happy-24">
              <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-24" class="delighted-24">
            </div>
          </div>
        </div>
      </div>
    </div>
    <div data-ix="display-none-on-load" class="w-row argument-row-3">
      <div class="w-col w-col-4 overview-3">
        <div class="sticky-footer">
          <h1 class="overview-heading">Overview&nbsp;</h1>
          <p class="basics-paragraph">The European Court of Human Rights (ECHR for short) and the EU are completely unrelated. Leaving the EU will have no impact on the UKs membership of the ECHR. The ECHR is part of the Council of Europe which the UK joined in 1951, a whole 22 years before it joined what we now know as the EU.</p>
          <div class="fill-empty-space"></div>
          <div class="emoticon-div">
            <div class="how-emoticons-work">How does this make you feel?</div>
            <div class="emoticons-25">
              <img width="50" src="images/angry with word.png" data-ix="anger-selected-25" class="anger-25">
              <img width="50" src="images/surprised with word.png" data-ix="shock-selected-25" class="shock-25">
              <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-25" class="indifferent-25">
              <img width="50" src="images/happy with word.png" data-ix="happy-selected-25" class="happy-25">
              <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-25" class="delighted-25">
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-4 leave-3">
        <div class="sticky-footer">
          <h1 class="leave-heading">Impact if we leave</h1>
          <p class="basics-paragraph"><span style="font-size: 18px; background-color: rgb(227, 16, 100);"><strong class="impact-answer-leave">None.</strong></span>
            <br>
            <br>We'd need to withdraw ourselves from the Human Rights Act in order to stop claims being taken to the ECHR.</p>
          <div class="fill-empty-space"></div>
          <div class="emoticon-div">
            <div class="how-emoticons-work">How does this make you feel?</div>
            <div class="emoticons-26">
              <img width="50" src="images/angry with word.png" data-ix="anger-selected-26" class="anger-26">
              <img width="50" src="images/surprised with word.png" data-ix="shock-selected-26" class="shock-26">
              <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-26" class="indifferent-26">
              <img width="50" src="images/happy with word.png" data-ix="happy-selected-26" class="happy-26">
              <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-26" class="delighted-26">
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-4 stay-3">
        <div class="sticky-footer">
          <h1 class="stay-heading">Impact if we stay</h1>
          <p class="basics-paragraph"><span style="font-size: 18px; background-color: rgb(38, 172, 199);"><strong class="impact-answer-stay">None.</strong></span>
            <br>
            <br>Politicians will still argue about rule making and some people will get shouty in parliament but besides that nothing much.</p>
          <div class="fill-empty-space"></div>
          <div class="emoticon-div">
            <div class="how-emoticons-work">How does this make you feel?</div>
            <div class="emoticons-27">
              <img width="50" src="images/angry with word.png" data-ix="anger-selected-27" class="anger-27">
              <img width="50" src="images/surprised with word.png" data-ix="shock-selected-27" class="shock-27">
              <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-27" class="indifferent-27">
              <img width="50" src="images/happy with word.png" data-ix="happy-selected-27" class="happy-27">
              <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-27" class="delighted-27">
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div id="Section-1" class="w-section section-1">
    <h1 class="blue-section-header">Here are the most popular Google searches on this topic answered, right here:</h1>
    <h4 class="how-to-use-the-grid-header">Most searched questions:</h4>
    <img width="25" src="images/down arrow.svg" data-ix="first-column-set-showhide" class="drop-down-topics">
    <div data-ix="display-none-on-load" class="w-row first-column-set">
      <div class="w-col w-col-5 column-1">
        <div class="card-1">
          <div class="sticky-footer">
            <h3 class="card-header-1">How much voting power does the UK have within EU?</h3>
            <h1 class="headline-fact">13%</h1>
            <a href="#" data-ix="p1" class="w-button button-1">More info</a>
            <p data-ix="display-none-on-load" class="p1">The UK has the third highest voting power in the Council of Ministers (behind Germany and France as the voting percentage is driven by population size). Most decisions are agreed by “consensus”, meaning that member state representatives work together to seek an agreement that all countries will be able to support. As a result, most votes are recorded with either no or only few countries abstaining or opposing legislation. Currently, between 20-25% of legislation has some form of opposition recorded by either a single or group of member state governments.</p>
            <div class="evidence"><a target="_blank" href="http://ukandeu.ac.uk/explainers/does-the-uk-win-or-lose-in-the-council-of-ministers/">Where did we get this from?</a>
            </div>
            <div class="fill-empty-space"></div>
            <div class="emoticon-div">
              <div class="how-emoticons-work">How does this make you feel?</div>
              <div class="emoticons">
                <img width="50" src="images/angry with word.png" data-ix="anger-selected" class="anger">
                <img width="50" src="images/surprised with word.png" data-ix="shock-selected" class="shock">
                <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected" class="indifferent">
                <img width="50" src="images/happy with word.png" data-ix="happy-selected" class="happy">
                <img width="50" src="images/delighted with word.png" data-ix="delighted-selected" class="delighted">
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-4 column-2">
        <div class="card-2">
          <div class="sticky-footer">
            <h3 class="card-header-2">Can the EU pass laws that the UK doesn't agree with?</h3>
            <h1 class="headline-phrase">It depends what it's about.</h1>
            <h1 class="headline-small">(but it's possible)</h1>
            <a href="#" data-ix="p2" class="w-button button-2">Show in&nbsp;context</a>
            <p data-ix="display-none-on-load" class="p2">Generally speaking the EU tries to pass the vast majority of its laws &nbsp;with member states unanimously agreeing (meaning every single one of them agree with it before it even goes to a vote). This is the case for approximately 75-85% of all law passed depending which study you look at. For those where member states object, it is taken to a vote. The UK is more likely then any other country to vote against the majority and be on the loosing side.</p>
            <div class="evidence"><a target="_blank" href="http://ukandeu.ac.uk/explainers/does-the-uk-win-or-lose-in-the-council-of-ministers/">Where did we get this from?</a>
            </div>
            <div class="fill-empty-space"></div>
            <div class="emoticon-div">
              <div class="how-emoticons-work">How does this make you feel?</div>
              <div class="emoticons-2">
                <img width="50" src="images/angry with word.png" data-ix="anger-selected-2" class="anger-2">
                <img width="50" src="images/surprised with word.png" data-ix="shock-selected-2" class="shock-2">
                <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-2" class="indifferent-2">
                <img width="50" src="images/happy with word.png" data-ix="happy-selected-2" class="happy-2">
                <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-2" class="delighted-2">
              </div>
            </div>
          </div>
        </div>
        <div class="card-3">
          <div class="sticky-footer">
            <h1 class="card-heading-3">How many times is the UK on the 'winning' side of the votes in the EU?</h1>
            <h1 class="headline-fact">86.70%</h1>
            <h1 class="headline-small">million</h1>
            <a href="#" data-ix="p3" class="w-button button-3">More info</a>
            <p data-ix="display-none-on-load" class="p3">The UK government was on the losing side a far higher proportion of times than any other EU government in the 2009-15 period: jumping from being on the minority (losing) side only 2.6% of the time in 2004-09 to being on the minority (losing) side 12.3% of the time in the 2009-15 period.
              <br>
              <br>Also, the next most frequent “losing” governments, Germany and Austria, were only on the minority side 5.4% of the time in this period.One thing to note, though, is the very high level of agreement in the Council in both periods. Put the other way round, the UK voted on the winning side 97.4% of the time in 2004-09 period and 86.7% of the time in the 2009-15 period.</p>
            <div class="evidence"><a target="_blank" href="http://ukandeu.ac.uk/explainers/does-the-uk-win-or-lose-in-the-council-of-ministers/">Where did we get this from?</a>
            </div>
            <div class="fill-empty-space"></div>
            <div class="emoticon-div">
              <div class="how-emoticons-work">How does this make you feel?</div>
              <div class="emoticons-3">
                <img width="50" src="images/angry with word.png" data-ix="anger-selected-3" class="anger-3">
                <img width="50" src="images/surprised with word.png" data-ix="shock-selected-3" class="shock-3">
                <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-3" class="indifferent-3">
                <img width="50" src="images/happy with word.png" data-ix="happy-selected-3" class="happy-3">
                <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-3" class="delighted-3">
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-3 column-3">
        <div class="card-4">
          <div class="sticky-footer">
            <h1 class="card-heading-4">Does the UK vote against proposed EU law?</h1>
            <h1 class="headline-fact">Yes</h1>
            <h1 class="headline-small">(more then any other country)</h1>
            <a href="#" data-ix="p4" class="w-button button-4">More info</a>
            <p data-ix="display-none-on-load" class="p4">The UK voted&nbsp;against&nbsp;the majority more frequently on budgetary policies, foreign and security policy, and international development, and voted&nbsp;with&nbsp;the majority more frequently on international trade, industry, environment, transport, legal affairs, economic and monetary union, and internal market policies.
              <br>
              <br> In most policy areas, the UK was again the member state most likely to vote against the majority, and significantly more likely than the average government in the EU.
              <br>
              <br>Nevertheless, the UK was not the most oppositional government on several important issue areas: internal market, legal affairs, transport, environment, and fisheries.</p>
            <div class="evidence"><a target="_blank" href="http://ukandeu.ac.uk/explainers/does-the-uk-win-or-lose-in-the-council-of-ministers/">Where did we get this from?</a>
            </div>
            <div class="fill-empty-space"></div>
            <div class="emoticon-div">
              <div class="how-emoticons-work">How does this make you feel?</div>
              <div class="emoticons-4">
                <img width="50" src="images/angry with word.png" data-ix="anger-selected-4" class="anger-4">
                <img width="50" src="images/surprised with word.png" data-ix="shock-selected-4" class="shock-4">
                <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-4" class="indifferent-4">
                <img width="50" src="images/happy with word.png" data-ix="happy-selected-4" class="happy-4">
                <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-4" class="delighted-4">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div data-ix="display-none-on-load" class="w-row second-column-set">
      <div class="w-col w-col-5 cc1">
        <div class="card-5">
          <div class="sticky-footer">
            <h1 class="card-header-5">What percentage of laws that the EU makes directly impacts the UK?</h1>
            <h1 class="headline-fact">13%</h1>
            <h1 class="headline-small">of 'significant' acts of legislation</h1>
            <a href="#" data-ix="p5" class="w-button button-5">More info</a>
            <p data-ix="display-none-on-load" class="p5">The EU influence on&nbsp;UK-only laws is about 13%. If you count EU regulations as part of 'UK law' then it is nearer 66%. But this counting exercise doesn't tell us very much. We may all be equal before the law, but not all laws are created equal; it's hard to say that an EU regulation on the methods of olive oil analysis is as important as an Act of Parliament restructuring the NHS. The reason for this level of regulation varies but generally speaking the majority of these regulations ensure that a product/service in one country is equal in quality to that in another.</p>
            <div class="evidence"><a target="_blank" href="https://fullfact.org/europe/two-thirds-uk-law-made-eu/">Where did we get this from?</a>
            </div>
            <div class="fill-empty-space"></div>
            <div class="emoticon-div">
              <div class="how-emoticons-work">How does this make you feel?</div>
              <div class="emoticons-5">
                <img width="50" src="images/angry with word.png" data-ix="anger-selected-5" class="anger-5">
                <img width="50" src="images/surprised with word.png" data-ix="shock-selected-5" class="shock-5">
                <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-5" class="indifferent-5">
                <img width="50" src="images/happy with word.png" data-ix="happy-selected-5" class="happy-5">
                <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-5" class="delighted-5">
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-4 cc2">
        <div class="card-6">
          <div class="sticky-footer">
            <h1 class="card-header-6">Does the EU ever 'give back' power to the UK?</h1>
            <h1 class="headline-fact">Yes.</h1>
            <h1 class="headline-small">(but the types of power given back vary greatly.)</h1>
            <a href="#" data-ix="p6" class="w-button button-6">Show context</a>
            <p data-ix="display-none-on-load" class="p6">The Lisbon Treaty, negotiated under the previous Labour government, allowed the Coalition government to reclaim around 100 'powers' (specific legislative acts) back from the EU. However the government opted to retain (leave within the power of the EU) a further 35 'powers' including the European Arrest Warrant as they believed it was in the UKs best interest to do so.</p>
            <div class="evidence"><a target="_blank" href="https://fullfact.org/europe/ask-full-fact-have-100-eu-powers-been-returned-uk/">Where did we get this from?</a>
            </div>
            <div class="fill-empty-space"></div>
            <div class="emoticon-div">
              <div class="how-emoticons-work">How does this make you feel?</div>
              <div class="emoticons-6">
                <img width="50" src="images/angry with word.png" data-ix="anger-selected-6" class="anger-6">
                <img width="50" src="images/surprised with word.png" data-ix="shock-selected-6" class="shock-6">
                <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-6" class="indifferent-6">
                <img width="50" src="images/happy with word.png" data-ix="happy-selected-6" class="happy-6">
                <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-6" class="delighted-6">
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-3 cc3"></div>
    </div>
    <a href="#top" data-ix="display-none-on-load" class="w-button back-to-top">Back To Top</a>
  </div>
  <div id="Section-2" class="w-section section-2">
    <h4 class="how-to-use-the-grid-header">Impact of leaving</h4>
    <img width="25" src="images/down arrow.svg" data-ix="drop-down-section-3" class="drop-down-topics">
    <div data-ix="display-none-on-load" class="w-row third-column-set">
      <div class="w-col w-col-5 column-7">
        <div class="card-7">
          <div class="sticky-footer">
            <h1 class="card-heading-7">Will leaving the EU withdraw the UK from the European Court of Human Rights?</h1>
            <h1 class="headline-fact">No.</h1>
            <a href="#" data-ix="p7" class="w-button button-7">More info</a>
            <p data-ix="display-none-on-load" class="p7">The European Court of Human Rights (ECHR for short) and the EU are completely unrelated. Leaving the EU will have no impact on the UKs membership of the ECHR. The ECHR is part of the Council of Europe which the UK joined in 1951, a whole 22 years before it joined what we now know as the EU.</p>
            <div class="evidence"><a target="_blank" href="http://www.leaveorstay.co.uk/the-black-and-white">Where did we get this from?</a>
            </div>
            <div class="fill-empty-space"></div>
            <div class="emoticon-div">
              <div class="how-emoticons-work">How does this make you feel?</div>
              <div class="emoticons-7">
                <img width="50" src="images/angry with word.png" data-ix="anger-selected-7" class="anger-7">
                <img width="50" src="images/surprised with word.png" data-ix="shock-selected-7" class="shock-7">
                <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-7" class="indifferent-7">
                <img width="50" src="images/happy with word.png" data-ix="happy-selected-7" class="happy-7">
                <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-7" class="delighted-7">
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-4 column-8">
        <div class="card-8">
          <div class="sticky-footer">
            <h1 class="card-header-8">Will leaving the EU mean that we have complete control over all our laws?</h1>
            <h1 class="headline-fact large-text">No.</h1>
            <h1 class="headline-small">(But we will have substantially more control.)</h1>
            <a href="#" data-ix="p8" class="w-button button-8">More info</a>
            <p data-ix="display-none-on-load" class="p8">The UK is part of a whole host of different organisations and other 'super-national bodies' that govern UK law without being elected. These include the World Trade Organisation (which is un-elected by UK voters) commits the UK to supra-national regulation and arbitration, as well as NATO which includes the Article 5 obligation to come to the mutual defence of fellow members, which implies a loss of sovereignty over deploying UK forces. Whilst the EU impacts the UK day to day life of the country, withdrawing from the EU will not give back the UK full sovereign control.</p>
            <div class="evidence"><a target="_blank" href="http://www.nato.int/cps/en/natohq/topics_110496.htm">Where did we get this from?</a>
            </div>
            <div class="fill-empty-space"></div>
            <div class="emoticon-div">
              <div class="how-emoticons-work">How does this make you feel?</div>
              <div class="emoticons-8">
                <img width="50" src="images/angry with word.png" data-ix="anger-selected-8" class="anger-8">
                <img width="50" src="images/surprised with word.png" data-ix="shock-selected-8" class="shock-8">
                <img width="50" src="images/indifferent with word.png" data-ix="indifferent-selected-8" class="indifferent-8">
                <img width="50" src="images/happy with word.png" data-ix="happy-selected-8" class="happy-8">
                <img width="50" src="images/delighted with word.png" data-ix="delighted-selected-8" class="delighted-8">
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-3 column-9"></div>
    </div>
    <a href="#top" data-ix="display-none-on-load" class="w-button back-to-top-2">Back To Top</a>
  </div>
  <div class="w-section got-the-basics topics">
    <h1 class="basics-link">Thats Sovereignty and Law done for now</h1>
    <p class="lets-get-started-pap">You've now done all that you'd like to for the topic of Sovereignty and Law, up next we'll be moving onto Trade.
      <br>
      <br>Remember you dont have to react to every card, feel free to pick and choose what topics and cards you look at.</p>
    <a href="trade.php" class="w-button continue-button">Next topic &gt;</a>
    <a href="resultspage%202.html" class="w-button continue-button">Sovereignty results &gt;</a>
  </div>
  
  
  <!-- footer -->
  
  <div id="contact" class="w-section footer">
    <div class="w-row about-us">
      <div class="w-col w-col-4 our-pages">
        <h4 class="about-us-heading">Our Pages</h4>
        <div data-collapse="none" data-animation="default" data-duration="400" data-contain="1" class="w-nav footer-nav">
          <div class="w-container">
            <nav role="navigation" class="w-nav-menu">
              <a href="new-homepage.php" class="w-nav-link footer-page">Home</a>
              <a href="about-us.php" class="w-nav-link footer-page">About Us</a>
              <a href="the-black-and-white.php" class="w-nav-link footer-page">The Black &amp; White</a>
            </nav>
            <div class="w-nav-button">
              <div class="w-icon-nav-menu"></div>
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-4 about-us-block">
        <h4 class="about-us-heading">About Us</h4>
        <p>Designed with love at Exeter University
          <br>
          <br>Innovation Centre
          <br>Rennes Drive
          <br>EX4 4RN</p>
      </div>
      <div class="w-col w-col-4 get-in-touch">
        <h4 class="about-us-heading">Get in touch</h4>
        <p>Want to say hi? &nbsp; hello@leaveorstay.co.uk</p>
        <div class="make-twitter-central">
          <div class="w-widget w-widget-twitter twitter">
            <iframe src="https://platform.twitter.com/widgets/follow_button.html#screen_name=leaveorstayHQ&amp;show_count=false&amp;size=m&amp;show_screen_name=true&amp;dnt=true" scrolling="no" frameborder="0" allowtransparency="true" style="border: none; overflow: hidden; width: 100%; height: 21px;"></iframe>
          </div>
        </div>
        <div class="w-widget w-widget-facebook facebook">
          <iframe src="https://www.facebook.com/plugins/like.php?href=http%3A%2F%2Ffacebook.com%2FleaveorstayHQ&amp;layout=box_count&amp;locale=en_US&amp;action=like&amp;show_faces=false&amp;share=false" scrolling="no" frameborder="0" allowtransparency="true" style="border: none; overflow: hidden; width: 55px; height: 65px;"></iframe>
        </div>
      </div>
    </div>
  </div>
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <script type="text/javascript" src="js/webflow.js"></script>
  <!--[if lte IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/placeholders/3.0.2/placeholders.min.js"></script><![endif]-->
</body>
</html>