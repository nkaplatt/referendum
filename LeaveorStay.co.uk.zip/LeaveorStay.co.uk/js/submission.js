window.onload = function(){
	var email_submission = document.getElementsByClassName("w-button");
	
	alert('hi');
	
	email_submission[1].onclick = function() { //top email submission
		var signup_form = document.getElementsByClassName("sign-up-form");
		alert('register loaded');
	
		if (signup_form[0].childNodes[0].value === '') {
			alert('first registration box is empty');
		} else {
			for (var i=0; i<signup_form[0].childNodes.length; i++) {
				if (signup_form[0].childNodes[i].id == 'name') {
					alert('email found: ' + signup_form[0].childNodes[i].value + i);
				} else if (signup_form[0].childNodes[i].id == 'field') {
					alert('pass1 found: ' + signup_form[0].childNodes[i].value + i);
				} else if (signup_form[0].childNodes[i].id == 'field-2') {
					alert('pass2 found: ' + signup_form[0].childNodes[i].value + i);
				}
			}
		}
		
	}
	email_submission[3].onclick = function() { //login at bottom of the page
		var login_form = document.getElementsByClassName("login-form");
	
		alert('login loaded');
		
		if (login_form[0].childNodes[0].value === '') {
			alert('first login box is empty');
		} else {
			for (var i=0; i<login_form[0].childNodes.length; i++) {
				alert(login_form[0].childNodes[i].value + i);
				/*if (login_form[0].childNodes[i].id == 'name-2') {
					alert('email found: ' + login_form[0].childNodes[i].value + i);
				} else if (login_form[0].childNodes[i].id == 'field-3') {
					alert('pass1 found: ' + login_form[0].childNodes[i].value + i);
				}*/
			}
		}
		
	}
}