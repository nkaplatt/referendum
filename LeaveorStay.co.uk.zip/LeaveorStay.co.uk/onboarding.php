<!DOCTYPE html>
<!-- Last Published: Sun May 01 2016 23:29:55 GMT+0000 (UTC) -->
<?php
session_start();
$user_check = $_SESSION['login_user'];
?>
<html data-wf-site="56fd24aaaea6500c763220cf" data-wf-page="571d040486c1049c4c0ef583">
<head>
  <meta charset="utf-8">
  <title>Onboarding</title>
  <meta name="description" content="Should we leave or stay in the EU.  We provide accurate, impartial information on the referendum so that you can cast an informed vote.">
  <meta property="og:title" content="Onboarding">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/normalize.css">
  <link rel="stylesheet" type="text/css" href="css/webflow.css">
  <link rel="stylesheet" type="text/css" href="css/los-template.webflow.css">
  <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.4.7/webfont.js"></script>
  <script>
    WebFont.load({
        google: {
          families: ["Open Sans:300,300italic,400,400italic,600,600italic,700,700italic,800,800italic","Varela Round:400","Ubuntu:300,300italic,400,400italic,500,500italic,700,700italic","Lato:100,100italic,300,300italic,400,400italic,700,700italic,900,900italic","Montserrat:400,700","Raleway:100,200,300,regular,500,600,700,800,900"]
        }
      });
  </script>
  <script type="text/javascript" src="js/modernizr.js"></script>
  <link rel="shortcut icon" type="image/x-icon" href="images/Favicon.png">
  <link rel="apple-touch-icon" href="https://daks2k3a4ib2z.cloudfront.net/img/webclip.png">
  <script type="text/javascript">
    var _gaq = _gaq || [];
      _gaq.push(['_setAccount', 'UA-76346760-1'], ['_trackPageview']);
      (function() {
        var ga = document.createElement('script');
        ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
      })();
  </script>
</head>
<body class="body onboard">
  <div data-collapse="medium" data-animation="over-right" data-duration="400" data-contain="1" data-doc-height="1" class="w-nav navbar">
    <div class="w-container">
      <a href="index.html" class="w-nav-brand logo-container">
        <h1 class="logo-text"><strong>leave</strong>or<strong>stay</strong>.co.uk</h1>
      </a>
      <div class="topic-navigation">
        <img width="60" src="images/sov-word.png">
        <img width="60" src="images/economy icon final.png">
        <img width="60" src="images/immigration icon.png">
        <img width="60" src="images/law icon.png">
        <img width="60" src="images/law icon.png">
      </div>
      <div class="w-nav-button menu-button">
        <div class="w-icon-nav-menu"></div>
      </div>
    </div>
  </div>
  <div class="hero onboarding"></div>
  <a href="#" data-ix="started-chat" class="w-button start-chat">Start chat</a>
  <div class="w-section">
    <div class="w-container onboard-container">
      <h1>Have a conversation</h1>
      <div class="w-clearfix text-div">
        <p data-ix="display-none-on-load" class="los-text">Hey there!</p>
      </div>
      <div class="w-clearfix text-div">
        <p data-ix="display-none-on-load" class="los-text-2">Thanks for checking out leaveorstay! It’s both sides of the argument in one place- like doing hundreds of Google searches simultaneously and getting accurate, balanced answers all in a matter of seconds, without all the link clicking.</p>
      </div>
      <div class="w-clearfix text-div">
        <p data-ix="display-none-on-load" class="los-text-3">Do you have a specific topic/question in mind or would you like to know more about leaveorstay?</p>
      </div>
      <div class="text-div">
        <div data-ix="chat-2" class="w-clearfix user-div-1">
          <p data-ix="display-none-on-load" class="user-text">Take me to your topics. &nbsp; What is this thing?</p>
        </div>
      </div>
      <div class="w-clearfix text-div">
        <p data-ix="display-none-on-load" class="los-text-4">We show you the questions dominating the debate as well as the impact of voting either way and you can respond to what you read by clicking the emoticons that appear.</p>
      </div>
      <div class="text-div">
        <div data-ix="chat-3" class="w-clearfix user-div-2">
          <img width="60" src="images/indifferent without word.png" data-ix="display-none-on-load" class="user-text-2">
        </div>
      </div>
      <div class="text-div">
        <div data-ix="chat-4" class="w-clearfix user-div-3">
          <p data-ix="display-none-on-load" class="user-text-3">Yep, like that! Nice.</p>
        </div>
      </div>
      <div class="w-clearfix text-div">
        <p data-ix="display-none-on-load" class="los-text-5">Login into leaveorstay whenever you want and we’ll give you the latest on the referendum and hand craft a suggestion of which way you should vote alongside you, based on how you respond to what you read. &nbsp;All the content you read is verified and evidenced information that you know you can trust.</p>
      </div>
      <div class="w-clearfix text-div">
        <p data-ix="display-none-on-load" class="los-text-6">We suggest that you save your thoughts and visit us every couple of days. It’s free, quick and only requires an email and a password.</p>
      </div>
      <div class="w-clearfix text-div">
        <p data-ix="display-none-on-load" class="los-text-7">Is that okay?</p>
      </div>
      <div class="text-div">
        <div data-ix="email-yes" class="w-clearfix user-div-4">
          <p data-ix="display-none-on-load" class="user-text-4">Yes</p>
        </div>
      </div>
      <div class="text-div">
        <div data-ix="email-no" class="w-clearfix user-div-5">
          <p data-ix="display-none-on-load" class="user-text-5">No thanks</p>
        </div>
      </div>
      <div class="w-clearfix text-div">
        <p data-ix="display-none-on-load" class="user-email">(Email)</p>
      </div>
      <div class="w-clearfix text-div">
        <p data-ix="display-none-on-load" class="user-password">(Password)</p>
      </div>
      <div class="w-clearfix text-div">
        <p data-ix="display-none-on-load" class="los-text-8">Thanks, welcome aboard!</p>
      </div>
      <div class="w-clearfix text-div">
        <p data-ix="display-none-on-load" class="los-text-9">Up the top you’ll see the topics and your progress so bar. Clicking on a topic emoji will take you to that topic. Don’t feel you have to read and react to all topics, although we do recommend having a browse of all topics if you get a chance.</p>
      </div>
      <div class="w-clearfix text-div">
        <p data-ix="display-none-on-load" class="los-text-10">Here are the topics we suggest you get started with. We add new ones daily. Got your own question? You can ask us to put it on the list here.</p>
      </div>
      <div class="w-clearfix text-div">
        <p data-ix="display-none-on-load" class="los-text-11">Are you ready to get started?</p>
      </div>
      <div class="text-div">
        <div data-ix="chat-5" class="w-clearfix user-div-6">
          <p data-ix="display-none-on-load" class="user-text-6">Yeah, let’s do this</p>
        </div>
      </div>
      <div class="text-div">
        <div data-ix="chat-5" class="w-clearfix user-div-6">
          <p data-ix="display-none-on-load" class="user-text-7">I guess so</p>
        </div>
      </div>
      <div class="w-clearfix text-div">
        <p data-ix="display-none-on-load" class="los-text-12">Alright, let’s get started</p>
      </div>
    </div>
  </div>
  <div class="sticky-footer"></div>
  <div id="contact" class="w-section footer">
    <div class="w-row about-us">
      <div class="w-col w-col-4 our-pages">
        <h4 class="about-us-heading">Our Pages</h4>
        <div data-collapse="none" data-animation="default" data-duration="400" data-contain="1" class="w-nav footer-nav">
          <div class="w-container">
            <nav role="navigation" class="w-nav-menu">
              <a href="new-homepage.html" class="w-nav-link footer-page">Home</a>
              <a href="about-us.html" class="w-nav-link footer-page">About Us</a>
              <a href="the-black-and-white.html" class="w-nav-link footer-page">The Black &amp; White</a>
            </nav>
            <div class="w-nav-button">
              <div class="w-icon-nav-menu"></div>
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-4 about-us-block">
        <h4 class="about-us-heading">About Us</h4>
        <p>Designed with love at Exeter University
          <br>
          <br>Innovation Centre
          <br>Rennes Drive
          <br>EX4 4RN</p>
      </div>
      <div class="w-col w-col-4 get-in-touch">
        <h4 class="about-us-heading">Get in touch</h4>
        <p>Want to say hi? &nbsp; hello@leaveorstay.co.uk</p>
        <div class="make-twitter-central">
          <div class="w-widget w-widget-twitter twitter">
            <iframe src="https://platform.twitter.com/widgets/follow_button.html#screen_name=leaveorstayHQ&amp;show_count=false&amp;size=m&amp;show_screen_name=true&amp;dnt=true" scrolling="no" frameborder="0" allowtransparency="true" style="border: none; overflow: hidden; width: 100%; height: 21px;"></iframe>
          </div>
        </div>
        <div class="w-widget w-widget-facebook facebook">
          <iframe src="https://www.facebook.com/plugins/like.php?href=http%3A%2F%2Ffacebook.com%2FleaveorstayHQ&amp;layout=box_count&amp;locale=en_US&amp;action=like&amp;show_faces=false&amp;share=false" scrolling="no" frameborder="0" allowtransparency="true" style="border: none; overflow: hidden; width: 55px; height: 65px;"></iframe>
        </div>
      </div>
    </div>
  </div>
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <script type="text/javascript" src="js/webflow.js"></script>
  <!--[if lte IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/placeholders/3.0.2/placeholders.min.js"></script><![endif]-->
</body>
</html>