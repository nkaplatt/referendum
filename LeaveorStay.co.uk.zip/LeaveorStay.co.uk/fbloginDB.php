<?php
  require_once('fbFunctions.php');
  facebookLoginLogout( 'http://localhost/apps/fblogin/fbloginDB.php',
                       'http://localhost/LeaveorStay.co.uk/immigration.php');
  //                     'Users/James/Desktop/los-template.webflowMay/the-basics.html');
  //facebookLoginLogout( 'http://localhost/apps/fblogin/fbloginDB.php',
  //                     'http://localhost/apps/fblogin/fbloginDB.php');
?>
