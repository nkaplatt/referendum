<!DOCTYPE html>
<!-- Last Published: Sun May 01 2016 23:29:55 GMT+0000 (UTC) -->
<html data-wf-site="56fd24aaaea6500c763220cf" data-wf-page="5718c6da13df03a741a87132">
<head>
  <meta charset="utf-8">
  <title>EU Referendum - The basics</title>
  <meta name="description" content="Should we leave or stay in the EU.  We provide accurate, impartial information on the referendum so that you can cast an informed vote.">
  <meta property="og:title" content="EU Referendum - The basics">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/normalize.css">
  <link rel="stylesheet" type="text/css" href="css/webflow.css">
  <link rel="stylesheet" type="text/css" href="css/los-template.webflow.css">
  <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.4.7/webfont.js"></script>
  <script>
    WebFont.load({
        google: {
          families: ["Open Sans:300,300italic,400,400italic,600,600italic,700,700italic,800,800italic","Varela Round:400","Ubuntu:300,300italic,400,400italic,500,500italic,700,700italic","Lato:100,100italic,300,300italic,400,400italic,700,700italic,900,900italic","Montserrat:400,700","Raleway:100,200,300,regular,500,600,700,800,900"]
        }
      });
  </script>
  <script type="text/javascript" src="js/modernizr.js"></script>
  <link rel="shortcut icon" type="image/x-icon" href="images/Favicon.png">
  <link rel="apple-touch-icon" href="https://daks2k3a4ib2z.cloudfront.net/img/webclip.png">
  <script type="text/javascript">
    var _gaq = _gaq || [];
      _gaq.push(['_setAccount', 'UA-76346760-1'], ['_trackPageview']);
      (function() {
        var ga = document.createElement('script');
        ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
      })();
  </script>
</head>
<body class="body">
  <div data-collapse="medium" data-animation="default" data-duration="400" data-contain="1" class="w-nav navbar">
    <div class="w-container">
      <a href="new-homepage.php" class="w-nav-brand logo-container">
        <h1 class="logo-text"><strong>leave</strong>or<strong>stay</strong>.co.uk</h1>
      </a>
      <nav role="navigation" class="w-nav-menu">
        <a href="immigration.php" class="w-nav-link nav-link">Immigration</a>
        <a href="sovereignty-and-the-law.php" class="w-nav-link nav-link">Sovereignty</a>
        <a href="trade.php" class="w-nav-link nav-link">Trade</a>
        <a href="jobs.php" class="w-nav-link nav-link">Jobs</a>
        <a href="defence.php" class="w-nav-link nav-link">Defense</a>
        <a href="signup.php" class="w-button hero-button">Sign up/login</a>
      </nav>
      <div class="w-nav-button menu">
        <div class="w-icon-nav-menu"></div>
      </div>
    </div>
  </div>
  <div class="w-section hero">
    <div class="w-container hero-container basics">
      <h1 class="hero-title">welcome to</h1>
      <h1 class="hero-title word">The Basics.</h1>
      <h1 class="hero-title title-2">You're here because you just want<br>a place to start with the whole EU<br>Referendum thing.<br><br>Scroll down to see the top arguments <br>from both sides.</h1>
    </div>
  </div>
  <div class="w-section section">
    <div class="w-container what-is-this-container">
      <h1 class="bw-learn-more">What is the EU referendum all about?</h1>
      <p class="what-is-this-subtitle">The EU Referendum, due to be held on Thursday June 23rd 2016, is a chance for the citizens of the UK to have a say over whether the UK should stay in the European Union or vote to leave it. This page is dedicated to answering the fundamental questions that underpin the debate, ranging from why are we having this referendum to the top arguments put forward by both sides.
        <br>
        <br><strong>Explore the top arguments from both sides below:</strong>
      </p>
    </div>
  </div>
  <div class="w-section tb-slider-section">
    <h1 class="topic-header">Top reasons why people want to leave</h1>
    <div data-animation="slide" data-duration="500" data-infinite="1" class="w-slider tb-slider">
      <div class="w-slider-mask tb-mask">
        <div class="w-slide slide-1">
          <div class="w-container container-tb">
            <div class="key-point-1">
              <h1 class="card-1-header">Concerns over immigration</h1>
              <p class="card-text">'EU membership stops us controlling who comes into our country, on what terms, and who can be removed. The system is out of control.'</p>
              <a href="#" data-ix="show-overview-1" class="w-button show-overview-1">Click for more info</a>
            </div>
          </div>
        </div>
        <div class="w-slide slide-2">
          <div class="w-container container-tb">
            <div class="key-point-2">
              <h1 class="card-2-header">The membership fee</h1>
              <p class="card-text">'The UK sends £350 million a week to Brussels, which is money we could spend on our priorities like the NHS.'</p>
              <a href="#" data-ix="show-overview-2" class="w-button show-overview-2">Click for more info</a>
            </div>
          </div>
        </div>
        <div class="w-slide slide-3">
          <div class="w-container container-tb">
            <div class="key-point-3">
              <h1 class="why-people-card-header">A loss of sovereignty</h1>
              <p class="card-text">'EU law is supreme over UK law. This stops the British public from being able to vote out those who make our laws.'</p>
              <a href="#" data-ix="show-overview-3" class="w-button show-overview-3">Click for more info</a>
            </div>
          </div>
        </div>
      </div>
      <div data-ix="overview-hide" class="w-slider-arrow-left">
        <div class="w-icon-slider-left left-arrow"></div>
        <div class="next">Next Card</div>
      </div>
      <div data-ix="overview-hide" class="w-slider-arrow-right">
        <div class="w-icon-slider-right right-arrow"></div>
        <div class="next">Next Card</div>
      </div>
      <div class="w-slider-nav w-round slider-1-nav"></div>
    </div>
  </div>
  <div class="w-section argument-section">
    <div data-ix="display-none-on-load" class="w-row argument-row">
      <div class="w-col w-col-4 overview-1">
        <div class="sticky-footer">
          <h1 class="overview-heading">Overview&nbsp;</h1>
          <p class="basics-paragraph">The UK currently has over 600,000 new migrants entering the UK to live and work every year, an unsustainable amount given the size of the UK . To bring immigration under control experts suggest we need net migration levels (the number entering minus the number leaving ) to be about 100,000 or less. The UK does have an 'Australian' style points based system for non-EU migrants which doesn't apply to EU migrants BUT currently the majority of migrants are from non EU countries anyway.</p>
        </div>
      </div>
      <div class="w-col w-col-4 leave-1">
        <div class="sticky-footer">
          <h1 class="leave-heading">Impact if we leave</h1>
          <p class="basics-paragraph"><strong class="impact-answer-leave">Moderate</strong>.
            <br>
            <br>All migrants would have to enter through the same points based system and require a visa. No one knows how free movement of people would work for UK nationals abroad or under what terms EU nationals could enter the UK. However it is important to note that reform of the points based system would still need to take place by the UK government to truly bring migration levels under control.</p>
        </div>
      </div>
      <div class="w-col w-col-4 stay-1">
        <div class="sticky-footer">
          <h1 class="stay-heading">Impact if we stay</h1>
          <p class="basics-paragraph"><strong class="impact-answer-stay">Unknown</strong>.
            <br>
            <br>The main influx of EU migrants came from countries that joined the EU in 2004, which includes Poland and Bulgaria. With those countries now members there is not a large pool of economic migrants out there (besides Turkey) &nbsp;that could be 'released' and lead to a new wave. None the less the UK would still have to accept free movement rules but can reform its non EU points based system from within the EU.</p>
        </div>
      </div>
    </div>
    <div data-ix="display-none-on-load" class="w-row argument-row-2">
      <div class="w-col w-col-4 overview-2">
        <div class="sticky-footer">
          <h1 class="overview-heading">Overview&nbsp;</h1>
          <p class="basics-paragraph">The UK does not send £350m a week to Brussels - the rebate is deducted before the money is sent, which takes the contribution down to £276m a week (0.3% of GDP - or enough to runt he NHS in England for 18hrs) Each country within the EU pays an annual membership fee to the EU. Each country pays a different amount primarily driven by how many people live in that country and how many farmers they have (take a look at&nbsp;CAP)</p>
        </div>
      </div>
      <div class="w-col w-col-4 leave-2">
        <div class="sticky-footer">
          <h1 class="leave-heading">Impact if we leave</h1>
          <p class="basics-paragraph"><strong class="impact-answer-leave">Moderate.</strong>
            <br>
            <br> The UK would stop sending it's membership fee so the money would theoretically be 'saved'. However the 'costs' associated with setting up trade deals and spending money on things the EU gives back to the UK (like R&amp;D funds for universities) would mean that this money could be quickly spent.</p>
        </div>
      </div>
      <div class="w-col w-col-4 stay-2">
        <div class="sticky-footer">
          <h1 class="stay-heading">Impact if we stay</h1>
          <p class="basics-paragraph"><strong class="impact-answer-stay">Minimal</strong>.
            <br>
            <br>The UK would continue to pay its membership fee which does cost it, in purely fiscal terms, more then it puts in. There is also the chance that the membership fee could go up in the future as the EU becomes larger. However there is no current indication of this.</p>
        </div>
      </div>
    </div>
    <div data-ix="display-none-on-load" class="w-row argument-row-3">
      <div class="w-col w-col-4 overview-3">
        <div class="sticky-footer">
          <h1 class="overview-heading">Overview&nbsp;</h1>
          <p class="basics-paragraph">Every position within the EU is voted upon, although the majority are NOT voted on by voters like you and me but rather by people we elect here. EU law currently impacts around 66% of all UK law. However, the UK is part of other institutions that we don't elect that impact our laws including NATO (which states we must go to war if a fellow member is attacked) so withdrawing from the EU will not give us full control back but considerable portions of it.</p>
        </div>
      </div>
      <div class="w-col w-col-4 leave-3">
        <div class="sticky-footer">
          <h1 class="leave-heading">Impact if we leave</h1>
          <p class="basics-paragraph"><strong class="impact-answer-leave">Severe.</strong>
            <br>
            <br>The UK government will be largely 'supreme' &nbsp;meaning that politicians we've directly elected will have the final say over the majority of our laws. However the UK will still have to abide by laws made by other international institutions such as the UN, NATO, IMF, WTO and other acronyms.</p>
        </div>
      </div>
      <div class="w-col w-col-4 stay-3">
        <div class="sticky-footer">
          <h1 class="stay-heading">Impact if we stay</h1>
          <p class="basics-paragraph"><strong class="impact-answer-stay">Minimal.</strong>
            <br>
            <br>The UK already has one of the strongest voting powers within the EU and can either decide to try and reform the EU from the inside or play a more back seat role and just vote on laws that matter to it.
            <br>
            <br>Note: It's important to mention the reason that the EU has an impact over so many laws is primarily due to the desire to harmonise the trading of goods and services and movement of people across the EU.</p>
        </div>
      </div>
    </div>
  </div>
  <div class="w-section tb-slider-2-section">
    <h1 class="topic-head-2">Top reasons why people want to stay</h1>
    <div data-animation="slide" data-duration="500" data-infinite="1" class="w-slider tb-slider">
      <div class="w-slider-mask tb-mask">
        <div class="w-slide slide-1">
          <div class="w-container container-tb">
            <div class="key-point-1">
              <h1 class="card-1-header">A stronger economy as part of the EU</h1>
              <p class="card-text">'Almost half of everything we sell to the rest of the world we sell to Europe - and we get an average of £24 billion of investment into Britain per year from Europe.'</p>
              <a href="#" data-ix="show-overview-4" class="w-button show-overview-4">Click for more information</a>
            </div>
          </div>
        </div>
        <div class="w-slide slide-2">
          <div class="w-container container-tb">
            <div class="key-point-2">
              <h1 class="card-2-header">To keep the UK a world leader</h1>
              <p class="card-text">&nbsp;'In today’s complex world, the UK has more control over its destiny by staying inside organisations like the EU.'</p>
              <a href="#" data-ix="show-overview-5" class="w-button show-overview-5">Click for more information</a>
            </div>
          </div>
        </div>
        <div class="w-slide slide-3">
          <div class="w-container container-tb">
            <div class="key-point-3 big-card">
              <h1 class="reasons-card-header too-much-text-h">Stronger security within the EU</h1>
              <p class="card-text too-much-text">'In today’s world, many of the threats to Britain's security are global in nature - like the aggression of Russia, terrorism and cross-border crime. Being in Europe, working with our closest neighbours and partners to tackle these threats, makes Britain safer.'</p>
              <a href="#" data-ix="show-overview-6" class="w-button show-overview-6">Click for more information</a>
            </div>
          </div>
        </div>
      </div>
      <div data-ix="overview-hide-2" class="w-slider-arrow-left">
        <div class="w-icon-slider-left"></div>
        <div class="next">Next Card</div>
      </div>
      <div data-ix="overview-hide-2" class="w-slider-arrow-right right-arrow">
        <div class="w-icon-slider-right"></div>
        <div class="next">Next Card</div>
      </div>
      <div class="w-slider-nav w-round slider-1-nav"></div>
    </div>
  </div>
  <div class="w-section argument-2-section">
    <div data-ix="display-none-on-load" class="w-row argument-row-4">
      <div class="w-col w-col-4 overview-1">
        <div class="sticky-footer">
          <h1 class="overview-heading">Overview&nbsp;</h1>
          <p class="paragraph">The UK is the worlds 5th largest economy and has substantial trade with the EU with approximately 44% of all our goods exported going there. There is debate over the impact of regulation on UK business but generally speaking businesses only have to adhere to one set of rules to sell to 28 countries rather then 28 separate rules, thus making it easier. However the EU is a declining trade partner for the UK, &nbsp;taking 55% of all our trade in 2008 to nearer 44% today.&nbsp;</p>
        </div>
      </div>
      <div class="w-col w-col-4 leave-1">
        <div class="sticky-footer">
          <h1 class="stay-heading">Impact if we stay</h1>
          <p class="paragraph"><strong class="impact-answer-stay"><br>Moderate</strong>.
            <br>
            <br>The EU is a the single largest trading partner for the UK so maintaining the current arrangement is beneficial. The EU also has more elaborate trade agreements in the pipeline with major economies like the US, China and India so staying part of the EU could mean more favourable terms of trade as we are trading as part of a 500 million bloc rather then a 64 million person one.</p>
        </div>
      </div>
      <div class="w-col w-col-4 stay-1">
        <div class="sticky-footer">
          <h1 class="leave-heading">Impact if we leave</h1>
          <p class="paragraph"><strong class="impact-answer-leave">Severe.</strong>
            <br>
            <br>How this new trade arrangement will take place (under what model), at what cost and how long securing those negotiations will take is the big unknown. However the UK is a major economic power so there is no doubt that it would be able to trade with Europe and the rest of the world. No country has ever left the EU in its current format so the process of negotiations is still unclear.</p>
        </div>
      </div>
    </div>
    <div data-ix="display-none-on-load" class="w-row argument-row-5">
      <div class="w-col w-col-4 overview-2">
        <div class="sticky-footer">
          <h1 class="overview-heading">Overview&nbsp;</h1>
          <p class="paragraph">This point is largely a matter of personal opinion about the UKs relationship with the rest of the world . Currently the UK is a member of a whole host of international institutions including the United Nations, NATO and the World Bank all of which the UK &nbsp;represents itself at. The debate is over whether the UK should be a voice within Europe via the EU, the so called 'influence through participation idea', or as a completely standalone country separate from the affairs and concerns of the mainland continental Europe.</p>
        </div>
      </div>
      <div class="w-col w-col-4 leave-2">
        <div class="sticky-footer">
          <h1 class="stay-heading">Impact if we stay</h1>
          <p class="paragraph"><strong class="impact-answer-stay"><br>Moderate</strong>.
            <br>
            <br>The UK would have a choice as to what direction it wanted to take within the EU. It could either continue as it is and be a moderately successful player or it could push for reform and try and change the way the EU works to better promote both EU and UK interests around the world.</p>
        </div>
      </div>
      <div class="w-col w-col-4 stay-2">
        <div class="sticky-footer">
          <h1 class="leave-heading">Impact if we leave</h1>
          <p class="paragraph"><strong class="impact-answer-leave"><br>Moderate.</strong>
            <br>
            <br>The UK would becomes less attractive to partners like &nbsp;the US as we'd no longer be the entry point for them into the EU. There are also concerns over the impact o the UK exit on the rest of the EU and if that triggers additional countries to call for a referendum on their membership of the EU.
            <br>However the UK will remain a member of all other international institutions so it would still wield considerable world influence.</p>
        </div>
      </div>
    </div>
    <div data-ix="display-none-on-load" class="w-row argument-row-6">
      <div class="w-col w-col-4 overview-3">
        <div class="sticky-footer">
          <h1 class="overview-heading">Overview&nbsp;</h1>
          <p class="paragraph">Aside from a political and economic union, the EU is also a cornerstone in the UKs defence against current global threats including terrorism, cross border crime and Russian aggression. The EU is seen by many world leaders as a buffer between the US and Russia, using its political and economic might to stop Russian expansion and aggression by imposing sanctions collectively.</p>
        </div>
      </div>
      <div class="w-col w-col-4 leave-3">
        <div class="sticky-footer">
          <h1 class="stay-heading">Impact if we stay</h1>
          <p class="paragraph"><strong class="impact-answer-stay"><br>Moderate</strong>.
            <br>
            <br> The UK would benefit form continued access to the European Arrest Warrant, intelligence agency co-operation and standing as part of a unified bloc against Russia. However free movement of people would still pose a threat as people who are hostile to the UK can move fairly free through the borderless portions of the EU so this point would need to be addressed.</p>
        </div>
      </div>
      <div class="w-col w-col-4 stay-3">
        <div class="sticky-footer">
          <h1 class="leave-heading">Impact if we leave</h1>
          <p class="paragraph"><strong class="impact-answer-leave">Severe</strong>.
            <br>
            <br> The UK would have to renegotiate certain security arrangements &nbsp;like access to the European Arrest Warrant and &nbsp;EU countries intelligence databases &nbsp;(if allowed). It could also appear 'isolated' from mainland EU in the eyes of Russia. However it would have, theoretically, stricter border controls so the &nbsp;impact of threats to the UK entering it are potentially reduced.</p>
        </div>
      </div>
    </div>
  </div>
  <div class="w-section blue-card">
    <h1 class="blue-card-header">Top questions about the referendum:</h1>
    <h1 class="why-are-we-having-a-ref-header">Why are we having a referendum?</h1>
    <img width="30" src="images/down arrow.svg" data-ix="tb-drop-1" class="tb-drop-1">
    <p data-ix="display-none-on-load" class="why-ref-main-txt">The PM David Cameron made it a Conservative Party General Election pledge that the country&nbsp;would hold a referendum on the UKs membership of the EU by 2017. &nbsp; The referendum is set to take place on Thursday June 23rd.</p>
    <h1 class="why-are-we-having-a-ref-header">What is the question we're answering?</h1>
    <img width="30" src="images/down arrow.svg" data-ix="tb-drop-2" class="tb-drop-2">
    <p data-ix="display-none-on-load" class="question-text">Should the United Kingdom remain a member of the European Union or leave the European Union?
      <br>
      <br>The options on the ballot paper are:
      <br>
      <br>Remain a member of the European Union
      <br>Leave the European Union</p>
  </div>
  <div class="w-section got-the-basics">
    <h1 class="basics-link">Got the basics?</h1>
    <p class="lets-get-started-pap">Hopefully now that you've got a better understanding as to what this is all about we suggest you launch into the main site and explore the topics that matter to you.
      <br>
      <br><strong class="average-user-happy">A typical user reports feeling 'happy' with their decision after using leaveorstay for 5 minutes or more</strong>
    </p>
    <a href="immigration.php" class="w-button lets-get-started">Get started&nbsp;</a>
  </div>
  <div id="contact" class="w-section footer">
    <div class="w-row about-us">
      <div class="w-col w-col-4 our-pages">
        <h4 class="about-us-heading">Our Pages</h4>
        <div data-collapse="none" data-animation="default" data-duration="400" data-contain="1" class="w-nav footer-nav">
          <div class="w-container">
            <nav role="navigation" class="w-nav-menu">
              <a href="new-homepage.php" class="w-nav-link footer-page">Home</a>
              <a href="about-us.php" class="w-nav-link footer-page">About Us</a>
              <a href="the-black-and-white.php" class="w-nav-link footer-page">The Black &amp; White</a>
            </nav>
            <div class="w-nav-button">
              <div class="w-icon-nav-menu"></div>
            </div>
          </div>
        </div>
      </div>
      <div class="w-col w-col-4 about-us-block">
        <h4 class="about-us-heading">About Us</h4>
        <p>Designed with love at Exeter University
          <br>
          <br>Innovation Centre
          <br>Rennes Drive
          <br>EX4 4RN</p>
      </div>
      <div class="w-col w-col-4 get-in-touch">
        <h4 class="about-us-heading">Get in touch</h4>
        <p>Want to say hi? &nbsp; hello@leaveorstay.co.uk</p>
        <div class="make-twitter-central">
          <div class="w-widget w-widget-twitter twitter">
            <iframe src="https://platform.twitter.com/widgets/follow_button.html#screen_name=leaveorstayHQ&amp;show_count=false&amp;size=m&amp;show_screen_name=true&amp;dnt=true" scrolling="no" frameborder="0" allowtransparency="true" style="border: none; overflow: hidden; width: 100%; height: 21px;"></iframe>
          </div>
        </div>
        <div class="w-widget w-widget-facebook facebook">
          <iframe src="https://www.facebook.com/plugins/like.php?href=http%3A%2F%2Ffacebook.com%2FleaveorstayHQ&amp;layout=box_count&amp;locale=en_US&amp;action=like&amp;show_faces=false&amp;share=false" scrolling="no" frameborder="0" allowtransparency="true" style="border: none; overflow: hidden; width: 55px; height: 65px;"></iframe>
        </div>
      </div>
    </div>
  </div>
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <script type="text/javascript" src="js/webflow.js"></script>
  <!--[if lte IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/placeholders/3.0.2/placeholders.min.js"></script><![endif]-->
</body>
</html>