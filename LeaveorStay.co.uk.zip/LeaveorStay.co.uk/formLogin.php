<?php

	session_start();
	if($_SERVER["REQUEST_METHOD"] == "POST") {
		//1. Create database connection
  		$dbhost = "localhost";
  		$dbuser = "root";
  		$dbpass = "Serious1sql";
  		$dbname = "EU_db";
  		$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
  		// Test if connection occured
  		if (mysqli_connect_errno()) {
    		die("Database connection failed: " .
    	    mysqli_connect_error() .
    	    " (" . mysqli_connect_errno() . ")"  );
  		}
  		echo "Working...";
  		
  		$email = mysqli_real_escape_string($connection,$_POST['email']);
    	$mypassword = mysqli_real_escape_string($connection,$_POST['password']);
    	
    	$sql = "SELECT MUser_ID FROM User_tbl ";
    	$sql .= "WHERE Email_Address = '$email' and ";
    	$sql .= "UPassword = '$mypassword';";
    	$result = mysqli_query($connection, $sql);
    	
    	if(mysqli_fetch_assoc($result) != null) {
    		//session_register("myemail");
	  		$email_noSalt = $email;
	  		$email = $email . 'EU';
	  		$Session_ID = hash('sha256', $email);
    	    $_SESSION['login_user'] = $Session_ID; 
    	    header("location: welcome.php");
    	} else {
    		$error = "Your login name/password is invalid";
    	}
    	/*
    	$email_address = $email . 'EU';
      	$Session_ID = hash('sha256', $email_address);
      	echo $Session_ID;
		*/
	}
?>

